
"use strict";

/* =========================================================
   I18N
========================================================= */

const I18N = {

  zh:{
    welcome:"Welcome.",
    subtitle:"ZEN OS Web Desktop",
    timeCenter:"当前时间",
    systemStatus:"系统状态",
    music:"音乐",
    musicDesc:"本地播放器",
    game:"游戏",
    gameDesc:"猜数字",
    tools:"工具箱",
    toolsDesc:"随机数 · 时间戳",
    calculator:"计算器",
    calculatorDesc:"基础计算",
    files:"文件",
    filesDesc:"文件中心",
    photos:"照片",
    photosDesc:"图片中心",
    float:"浮字引擎",
    floatDesc:"动态文字系统",
    translator:"翻译器",
    translatorDesc:"中英文翻译",
    notice:"通知",
    noticeDesc:"系统消息",
    settings:"设置",
    settingsDesc:"主题 · 语言 · 系统",
    search:"搜索",
    searchDesc:"搜索 App",
    about:"关于 ZEN OS",
    profile:"个人中心",
    profileDesc:"头像 · 昵称 · 状态",
    profileCenter:"个人中心",
    nickname:"昵称",
    signature:"个性签名",
    profileStatus:"状态",
    statusOnline:"在线",
    statusBusy:"忙碌",
    statusAway:"离开",
    statusOffline:"隐身",
    chooseAvatar:"选择头像",
    saveProfile:"保存资料",
    profileSaved:"个人资料已保存",
    resetAvatar:"移除头像",
    localProfileNote:"当前资料仅保存在此浏览器，不会自动上传服务器。",
    telegram:"Telegram 社群",
    telegramDesc:"加入 ZEN OS 官方社群",
    online:"在线",
    offline:"离线",
    ready:"系统就绪",
    charging:"充电中",
    theme:"主题中心",
    language:"语言",
    dark:"深色模式",
    light:"浅色模式",
    auto:"跟随系统",
    save:"保存",
    close:"关闭",
    complete:"完成",
    musicCenter:"音乐中心",
    chooseMusic:"选择本地音乐",
    choosePhotos:"导入照片",
    chooseFiles:"选择文件",
    noFiles:"暂时没有文件",
    noPhotos:"暂时没有照片",
    translate:"翻译",
    sourceText:"输入文本...",
    result:"翻译结果",
    clear:"清空",
    random:"随机数",
    timestamp:"时间戳",
    guess:"猜数字",
    floatText:"浮字内容",
    enabled:"已开启",
    disabled:"已关闭",
    pin:"锁屏 PIN",
    system:"系统",
    performance:"性能模式",
    reset:"重置设置",
    searchApp:"搜索 App...",
    noResult:"没有找到 App",
    noticeWelcome:"欢迎使用 ZEN OS V19",
    announcementCenter:"公告中心",
    announcementLatest:"最新公告",
    announcementRead:"已读",
    announcementUnread:"未读",
    markRead:"标记已读",
    markAllRead:"全部已读",
    noAnnouncements:"暂无公告",
    announcementPinned:"置顶",
    announcementNew:"NEW",
    controlCenter:"控制中心",
    controlDesc:"桌面与系统控制",
    stopwatch:"秒表",
    stopwatchDesc:"计时器",
    game2048:"2048",
    game2048Desc:"数字合成游戏",
    fullscreen:"全屏",
    wallpaper:"动态壁纸",
    wallpaperOn:"动态壁纸已开启",
    wallpaperOff:"动态壁纸已关闭",
    resetTimer:"重置",
    start:"开始",
    pause:"暂停",
    newGame:"新游戏",
    controlCenterTitle:"控制中心",
    spectrum:"音乐频谱",
    localTranslate:"本地翻译模式",
    selectLanguage:"选择语言",
    systemBattery:"电池",
    noBattery:"浏览器不支持电池 API",
    musicEmpty:"还没有载入音乐",
    photosEmpty:"还没有导入照片",
    filesEmpty:"还没有选择文件",
    guessStart:"开始游戏",
    bigger:"大一点",
    smaller:"小一点",
    correct:"猜中了！",
    inputNumber:"请输入数字",
    rangeError:"范围输入错误",
    saved:"已保存",
    copied:"已复制",
    resetDone:"设置已重置",
    floatSaved:"浮字已保存",
    floatOn:"浮字已开启",
    floatOff:"浮字已关闭",
    floatMode:"浮字模式",
    floatModeRise:"上浮",
    floatModeDrift:"漂移",
    floatModeSide:"横向",
    floatModePulse:"脉冲",
    floatSpeed:"动画速度",
    floatDensity:"出现频率",
    floatOpacity:"透明度",
    floatSize:"文字大小",
    floatMax:"最大数量",
    floatPreview:"预览",
    floatReset:"恢复默认",
    floatSavedV4:"浮字 V4 设置已保存",
    serverApi:"服务器 API",
    serverApiUrl:"API 地址",
    serverApiEnabled:"启用服务器 API",
    serverApiAnnouncements:"从服务器加载公告",
    apiSave:"保存 API 设置",
    apiTest:"测试连接",
    apiOnline:"API 在线",
    apiOffline:"API 离线",
    apiSaved:"API 设置已保存"
  },

  en:{
    welcome:"Welcome.",
    subtitle:"ZEN OS Web Desktop",
    timeCenter:"Time Center",
    systemStatus:"System Status",
    music:"Music",
    musicDesc:"Local Player",
    game:"Game",
    gameDesc:"Guess Number",
    tools:"Tools",
    toolsDesc:"Random · Timestamp",
    calculator:"Calculator",
    calculatorDesc:"Basic Calculator",
    files:"Files",
    filesDesc:"File Center",
    photos:"Photos",
    photosDesc:"Photo Center",
    float:"Floating Text",
    floatDesc:"Dynamic Text Engine",
    translator:"Translator",
    translatorDesc:"Chinese / English",
    notice:"Notifications",
    noticeDesc:"System Messages",
    settings:"Settings",
    settingsDesc:"Theme · Language · System",
    search:"Search",
    searchDesc:"Search Apps",
    about:"About ZEN OS",
    profile:"Personal Center",
    profileDesc:"Avatar · Name · Status",
    profileCenter:"Personal Center",
    nickname:"Nickname",
    signature:"Signature",
    profileStatus:"Status",
    statusOnline:"Online",
    statusBusy:"Busy",
    statusAway:"Away",
    statusOffline:"Invisible",
    chooseAvatar:"Choose Avatar",
    saveProfile:"Save Profile",
    profileSaved:"Profile saved",
    resetAvatar:"Remove Avatar",
    localProfileNote:"This profile is stored only in this browser and is not uploaded automatically.",
    telegram:"Telegram Community",
    telegramDesc:"Join the ZEN OS community",
    online:"Online",
    offline:"Offline",
    ready:"System Ready",
    charging:"Charging",
    theme:"Theme Center",
    language:"Language",
    dark:"Dark Mode",
    light:"Light Mode",
    auto:"System",
    save:"Save",
    close:"Close",
    complete:"Done",
    musicCenter:"Music Center",
    chooseMusic:"Choose Local Music",
    choosePhotos:"Import Photos",
    chooseFiles:"Choose Files",
    noFiles:"No files",
    noPhotos:"No photos",
    translate:"Translate",
    sourceText:"Enter text...",
    result:"Translation",
    clear:"Clear",
    random:"Random Number",
    timestamp:"Timestamp",
    guess:"Guess Number",
    floatText:"Floating Text",
    enabled:"Enabled",
    disabled:"Disabled",
    pin:"Lock PIN",
    system:"System",
    performance:"Performance Mode",
    reset:"Reset Settings",
    searchApp:"Search Apps...",
    noResult:"No App Found",
    noticeWelcome:"Welcome to ZEN OS V19",
    announcementCenter:"Announcement Center",
    announcementLatest:"Latest Announcements",
    announcementRead:"Read",
    announcementUnread:"Unread",
    markRead:"Mark as read",
    markAllRead:"Mark all read",
    noAnnouncements:"No announcements",
    announcementPinned:"Pinned",
    announcementNew:"NEW",
    controlCenter:"Control Center",
    controlDesc:"Desktop & System Controls",
    stopwatch:"Stopwatch",
    stopwatchDesc:"Timer",
    game2048:"2048",
    game2048Desc:"Number Merge Game",
    fullscreen:"Fullscreen",
    wallpaper:"Dynamic Wallpaper",
    wallpaperOn:"Dynamic wallpaper enabled",
    wallpaperOff:"Dynamic wallpaper disabled",
    resetTimer:"Reset",
    start:"Start",
    pause:"Pause",
    newGame:"New Game",
    controlCenterTitle:"Control Center",
    spectrum:"Music Spectrum",
    localTranslate:"Local Translation",
    selectLanguage:"Language",
    systemBattery:"Battery",
    noBattery:"Battery API unavailable",
    musicEmpty:"No music loaded",
    photosEmpty:"No photos",
    filesEmpty:"No files selected",
    guessStart:"Start Game",
    bigger:"Higher",
    smaller:"Lower",
    correct:"Correct!",
    inputNumber:"Enter a number",
    rangeError:"Invalid range",
    saved:"Saved",
    copied:"Copied",
    resetDone:"Settings reset",
    floatSaved:"Floating text saved",
    floatOn:"Floating text enabled",
    floatOff:"Floating text disabled",
    floatMode:"Float Mode",
    floatModeRise:"Rise",
    floatModeDrift:"Drift",
    floatModeSide:"Side",
    floatModePulse:"Pulse",
    floatSpeed:"Animation Speed",
    floatDensity:"Spawn Rate",
    floatOpacity:"Opacity",
    floatSize:"Text Size",
    floatMax:"Maximum Items",
    floatPreview:"Preview",
    floatReset:"Reset Defaults",
    floatSavedV4:"Float V4 settings saved",
    serverApi:"Server API",
    serverApiUrl:"API Base URL",
    serverApiEnabled:"Enable Server API",
    serverApiAnnouncements:"Load announcements from server",
    apiSave:"Save API Settings",
    apiTest:"Test Connection",
    apiOnline:"API Online",
    apiOffline:"API Offline",
    apiSaved:"API settings saved"
  }

};


/* =========================================================
   STATE
========================================================= */

const STORE_KEY = "ZEN_OS_V19_STATE";
const LEGACY_STORE_KEY = "ZEN_OS_V18_STATE";
const APP_VERSION = "19.0";
const TELEGRAM_COMMUNITY_URL = "https://t.me/ZENOSpd";

const state = {

  theme:"dark",
  language:"zh",

  floatEnabled:true,
  floatText:"ZEN OS",
  floatMode:"rise",
  floatSpeed:1,
  floatDensity:1,
  floatOpacity:.55,
  floatSize:16,
  floatMax:18,

  performance:false,

  pin:"",

  musicTracks:[],
  currentTrack:-1,

  files:[],
  photos:[],

  announcementRead:[],

  dynamicWallpaper:true,

  /* Server API */
  serverApiUrl:"https://zenos-91.onrender.com/api",
  serverApiEnabled:true,
  serverApiAnnouncements:true,

  /* Personal Center */
  profileNickname:"十壹",
  profileSignature:"ZEN OS 用户",
  profileStatus:"online",
  profileAvatar:""

};

let clockTimer = null;
let floatTimer = null;
let toastTimer = null;
let currentModal = null;
let batteryManager = null;

let gameTarget = 0;
let gameAttempts = 0;

let audioContext = null;
let audioAnalyser = null;
let audioSourceNode = null;
let spectrumAudio = null;
let spectrumFrame = 0;

/* PIN 防暴力尝试：仅用于前端锁屏保护。
   注意：纯 HTML/JS 无法防止拥有源码/DevTools 权限的人绕过 PIN。 */
const PIN_MAX_ATTEMPTS = 5;
const PIN_LOCK_MS = 30000;
let pinFailedAttempts = 0;
let pinLockedUntil = 0;


/* =========================================================
   SAFE DOM
========================================================= */

function $(id){
  return document.getElementById(id);
}


/* =========================================================
   TRANSLATION
========================================================= */

function t(key){

  return (
    I18N[state.language] &&
    I18N[state.language][key]
  ) || key;

}


/* =========================================================
   STORAGE
========================================================= */

function saveState(){

  try{

    const data = {
      version:APP_VERSION,
      theme:state.theme,
      language:state.language,
      floatEnabled:state.floatEnabled,
      floatText:state.floatText,
      floatMode:state.floatMode,
      floatSpeed:state.floatSpeed,
      floatDensity:state.floatDensity,
      floatOpacity:state.floatOpacity,
      floatSize:state.floatSize,
      floatMax:state.floatMax,
      performance:state.performance,
      pin:state.pin,
      announcementRead:Array.isArray(state.announcementRead) ? state.announcementRead.slice(0,100) : [],
      dynamicWallpaper:state.dynamicWallpaper !== false,
      serverApiUrl:typeof state.serverApiUrl === "string" ? state.serverApiUrl.slice(0,500) : "https://zenos-91.onrender.com/api",
      serverApiEnabled:state.serverApiEnabled !== false,
      serverApiAnnouncements:state.serverApiAnnouncements !== false,
      profileNickname:typeof state.profileNickname === "string" ? state.profileNickname.slice(0,40) : "十壹",
      profileSignature:typeof state.profileSignature === "string" ? state.profileSignature.slice(0,120) : "ZEN OS 用户",
      profileStatus:["online","busy","away","offline"].includes(state.profileStatus) ? state.profileStatus : "online",
      profileAvatar:typeof state.profileAvatar === "string" ? state.profileAvatar.slice(0,500000) : ""
    };

    localStorage.setItem(
      STORE_KEY,
      JSON.stringify(data)
    );

  }catch(err){

    console.warn(
      "Storage save failed",
      err
    );

  }

}


function loadState(){

  try{

    let raw =
      localStorage.getItem(STORE_KEY);

    if(!raw){
      raw = localStorage.getItem(LEGACY_STORE_KEY);
      if(raw){
        try{
          localStorage.setItem(STORE_KEY, raw);
          localStorage.removeItem(LEGACY_STORE_KEY);
        }catch(e){}
      }
    }

    if(!raw)
      return;

    const saved =
      JSON.parse(raw);

    if(
      !saved ||
      typeof saved !== "object"
    )
      return;

    state.theme =
      ["dark","light","auto"].includes(saved.theme)
        ? saved.theme
        : "dark";

    state.language =
      saved.language === "en"
        ? "en"
        : "zh";

    state.floatEnabled =
      saved.floatEnabled !== false;

    state.floatText =
      typeof saved.floatText === "string" &&
      saved.floatText.trim()
        ? saved.floatText.slice(0,100)
        : "ZEN OS";

    state.floatMode = ["rise","drift","side","pulse"].includes(saved.floatMode) ? saved.floatMode : "rise";
    state.floatSpeed = Number.isFinite(Number(saved.floatSpeed)) ? Math.min(2, Math.max(.4, Number(saved.floatSpeed))) : 1;
    state.floatDensity = Number.isFinite(Number(saved.floatDensity)) ? Math.min(3, Math.max(.5, Number(saved.floatDensity))) : 1;
    state.floatOpacity = Number.isFinite(Number(saved.floatOpacity)) ? Math.min(1, Math.max(.15, Number(saved.floatOpacity))) : .55;
    state.floatSize = Number.isFinite(Number(saved.floatSize)) ? Math.min(32, Math.max(10, Number(saved.floatSize))) : 16;
    state.floatMax = Number.isFinite(Number(saved.floatMax)) ? Math.min(40, Math.max(4, Math.floor(Number(saved.floatMax)))) : 18;

    state.performance =
      saved.performance === true;

    state.pin =
      /^\d{4}$/.test(saved.pin || "")
        ? saved.pin
        : "";

    state.dynamicWallpaper = saved.dynamicWallpaper !== false;
    state.serverApiUrl = typeof saved.serverApiUrl === "string" && saved.serverApiUrl.trim() ? saved.serverApiUrl.trim().slice(0,500) : "https://zenos-91.onrender.com/api";
    state.serverApiEnabled = saved.serverApiEnabled !== false;
    state.serverApiAnnouncements = saved.serverApiAnnouncements !== false;
    state.profileNickname = typeof saved.profileNickname === "string" && saved.profileNickname.trim() ? saved.profileNickname.slice(0,40) : "十壹";
    state.profileSignature = typeof saved.profileSignature === "string" ? saved.profileSignature.slice(0,120) : "ZEN OS 用户";
    state.profileStatus = ["online","busy","away","offline"].includes(saved.profileStatus) ? saved.profileStatus : "online";
    state.profileAvatar = typeof saved.profileAvatar === "string" ? saved.profileAvatar.slice(0,500000) : "";

    state.announcementRead =
      Array.isArray(saved.announcementRead)
        ? saved.announcementRead.filter(id => typeof id === "string").slice(0,100)
        : [];

  }catch(err){

    console.warn(
      "Storage load failed",
      err
    );

    state.theme = "dark";
    state.language = "zh";
    state.floatEnabled = true;
    state.floatText = "ZEN OS";
    state.floatMode = "rise";
    state.floatSpeed = 1;
    state.floatDensity = 1;
    state.floatOpacity = .55;
    state.floatSize = 16;
    state.floatMax = 18;
    state.profileNickname = "十壹";
    state.profileSignature = "ZEN OS 用户";
    state.profileStatus = "online";
    state.profileAvatar = "";
    state.performance = false;
    state.pin = "";

  }

}


/* =========================================================
   THEME
========================================================= */

function applyTheme(){

  document.body.classList.remove("light");

  if(state.theme === "light"){

    document.body.classList.add("light");

  }

  if(state.theme === "auto"){

    try{

      const media =
        window.matchMedia(
          "(prefers-color-scheme:light)"
        );

      if(media.matches)
        document.body.classList.add("light");

    }catch(e){}

  }

  document.body.classList.toggle("dynamicWallpaper", state.dynamicWallpaper && !state.performance);
  updateMetaTheme();

}


function updateMetaTheme(){

  const meta =
    document.querySelector(
      'meta[name="theme-color"]'
    );

  if(meta){

    meta.content =
      document.body.classList.contains("light")
        ? "#edf1f8"
        : "#080b14";

  }

}


function cycleTheme(){

  if(state.theme === "dark")
    state.theme = "light";
  else if(state.theme === "light")
    state.theme = "auto";
  else
    state.theme = "dark";

  saveState();
  applyTheme();

  toast(themeName());

}


function themeName(){

  if(state.theme === "light")
    return t("light");

  if(state.theme === "auto")
    return t("auto");

  return t("dark");

}


/* =========================================================
   LANGUAGE
========================================================= */

function applyLanguage(){

  document.documentElement.lang =
    state.language === "zh"
      ? "zh-CN"
      : "en";

  document
    .querySelectorAll("[data-i18n]")
    .forEach(el => {

      const key =
        el.getAttribute("data-i18n");

      el.textContent = t(key);

    });

  if($("heroTitle"))
    $("heroTitle").textContent = t("welcome");

  if($("heroSub"))
    $("heroSub").textContent = t("subtitle");

  updateNetwork();
  updateBatteryUI();
  updateAnnouncementBar();

}


/* =========================================================
   CLOCK
========================================================= */

function updateClock(){

  const d = new Date();

  const locale =
    state.language === "zh"
      ? "zh-CN"
      : "en-US";

  const time =
    d.toLocaleTimeString(
      locale,
      {
        hour:"2-digit",
        minute:"2-digit",
        second:"2-digit",
        hour12:false
      }
    );

  const date =
    d.toLocaleDateString(
      locale,
      {
        year:"numeric",
        month:"long",
        day:"numeric",
        weekday:"long"
      }
    );

  [
    "topTime",
    "heroTime",
    "bigTime",
    "lockTime"
  ].forEach(id => {

    const el = $(id);

    if(el)
      el.textContent = time;

  });

  [
    "heroDate",
    "bigDate",
    "lockDate"
  ].forEach(id => {

    const el = $(id);

    if(el)
      el.textContent = date;

  });

  const modalClock =
    $("modalClock");

  if(modalClock)
    modalClock.textContent = time;

}


/* =========================================================
   NETWORK
========================================================= */

function updateNetwork(){

  const online =
    navigator.onLine;

  if($("networkText"))
    $("networkText").textContent =
      online
        ? t("online")
        : t("offline");

  if($("systemStatus"))
    $("systemStatus").textContent =
      online
        ? t("ready")
        : t("offline");

}


window.addEventListener(
  "online",
  updateNetwork
);

window.addEventListener(
  "offline",
  updateNetwork
);


/* =========================================================
   BATTERY
========================================================= */

async function initBattery(){

  try{

    if(
      !navigator.getBattery ||
      typeof navigator.getBattery !== "function"
    ){

      updateBatteryUnsupported();
      return;

    }

    batteryManager =
      await navigator.getBattery();

    updateBatteryUI();

    batteryManager.addEventListener(
      "levelchange",
      updateBatteryUI
    );

    batteryManager.addEventListener(
      "chargingchange",
      updateBatteryUI
    );

  }catch(err){

    console.warn(
      "Battery unavailable",
      err
    );

    updateBatteryUnsupported();

  }

}


function updateBatteryUnsupported(){

  if($("batteryText"))
    $("batteryText").textContent = "—";

  if($("systemBattery"))
    $("systemBattery").textContent = "—";

}


function updateBatteryUI(){

  if(!batteryManager){

    if(
      !navigator.getBattery ||
      typeof navigator.getBattery !== "function"
    )
      updateBatteryUnsupported();

    return;

  }

  const level =
    Math.round(
      batteryManager.level * 100
    );

  if($("batteryText"))
    $("batteryText").textContent =
      level + "%";

  if($("systemBattery"))
    $("systemBattery").textContent =
      "🔋 " + level + "%";

  if($("systemStatus")){

    if(batteryManager.charging){

      $("systemStatus").textContent =
        "⚡ " + t("charging");

    }else{

      $("systemStatus").textContent =
        navigator.onLine
          ? t("ready")
          : t("offline");

    }

  }

}


/* =========================================================
   LOCK
========================================================= */

function enterSystem(){

  /*
    安全修复：设置了 PIN 后，任何入口都不能绕过锁屏。
    只有 PIN 为空时才允许直接进入。
  */
  if(state.pin){

    if($("lock"))
      $("lock").style.display = "flex";

    if($("app"))
      $("app").style.display = "none";

    const input = $("pinInput");
    if(input)
      input.focus();

    toast(
      state.language === "zh"
        ? "请先输入 PIN"
        : "Enter PIN first"
    );

    return false;

  }

  if($("lock"))
    $("lock").style.display = "none";

  if($("app"))
    $("app").style.display = "flex";

  startRuntime();

  toast(
    state.language === "zh"
      ? "欢迎进入 ZEN OS"
      : "Welcome to ZEN OS"
  );

  return true;

}


function unlock(){

  if(!state.pin){

    enterSystem();
    return;

  }

  const now = Date.now();

  if(pinLockedUntil > now){
    const sec = Math.ceil((pinLockedUntil - now) / 1000);
    toast(
      state.language === "zh"
        ? `尝试次数过多，请 ${sec} 秒后再试`
        : `Too many attempts. Try again in ${sec}s`
    );
    return;
  }

  const input = $("pinInput");
  const value = input ? input.value.trim() : "";

  if(!/^\d{4}$/.test(value)){
    toast(
      state.language === "zh"
        ? "请输入4位数字 PIN"
        : "Enter a 4-digit PIN"
    );
    if(input) input.value = "";
    return;
  }

  if(value === state.pin){
    pinFailedAttempts = 0;
    pinLockedUntil = 0;
    if(input) input.value = "";
    enterSystem();
    return;
  }

  pinFailedAttempts++;
  if(input) input.value = "";

  if(pinFailedAttempts >= PIN_MAX_ATTEMPTS){
    pinFailedAttempts = 0;
    pinLockedUntil = Date.now() + PIN_LOCK_MS;
    toast(
      state.language === "zh"
        ? "PIN 错误次数过多，已锁定30秒"
        : "Too many wrong PINs. Locked for 30s"
    );
  }else{
    const left = PIN_MAX_ATTEMPTS - pinFailedAttempts;
    toast(
      state.language === "zh"
        ? `PIN 错误，还可尝试 ${left} 次`
        : `Wrong PIN. ${left} attempts left`
    );
  }

}


/* =========================================================
   RUNTIME
========================================================= */

function startRuntime(){

  if(clockTimer)
    clearInterval(clockTimer);

  clockTimer =
    setInterval(
      updateClock,
      1000
    );

  if(floatTimer)
    clearInterval(floatTimer);

  if(stopwatchTimer)
    clearInterval(stopwatchTimer);

  releaseSpectrumNodes(true);

  scheduleFloatEngine();

  updateClock();

  // Server API is optional; failure falls back to built-in announcements.
  syncServerAnnouncements();

}


/* =========================================================
   FLOAT
========================================================= */

function scheduleFloatEngine(){

  if(floatTimer)
    clearInterval(floatTimer);

  const base = state.performance ? 3200 : 1700;
  const interval = Math.max(550, Math.round(base / Math.max(.5, state.floatDensity || 1)));

  floatTimer = setInterval(createFloatText, interval);
}

function createFloatText(){

  if(!state.floatEnabled || document.hidden)
    return;

  const layer = $("floatTextLayer");
  if(!layer)
    return;

  const current = layer.children.length;
  const max = Math.max(4, Math.min(40, Number(state.floatMax) || 18));
  if(current >= max)
    return;

  const el = document.createElement("div");
  el.className = "floatText float-" + (state.floatMode || "rise");
  el.textContent = state.floatText || "ZEN OS";

  const size = Math.max(10, Math.min(32, Number(state.floatSize) || 16));
  const opacity = Math.max(.15, Math.min(1, Number(state.floatOpacity) || .55));
  const speed = Math.max(.4, Math.min(2, Number(state.floatSpeed) || 1));
  const duration = (6 + Math.random()*4) / speed;

  el.style.left = (Math.random()*86 + 5) + "%";
  el.style.top = (24 + Math.random()*62) + "%";
  el.style.fontSize = (size * (.8 + Math.random()*.45)) + "px";
  el.style.setProperty("--float-opacity", opacity);
  el.style.animationDuration = duration + "s";

  if(state.floatMode === "side"){
    el.style.top = (30 + Math.random()*50) + "%";
  }

  if(state.floatMode === "pulse"){
    el.style.left = (20 + Math.random()*60) + "%";
    el.style.top = (30 + Math.random()*45) + "%";
  }

  layer.appendChild(el);

  const life = Math.ceil(duration * 1000 + 800);
  setTimeout(() => {
    if(el.parentNode)
      el.remove();
  }, life);
}

function clearFloatLayer(){

  const layer =
    $("floatTextLayer");

  if(layer)
    layer.innerHTML = "";

}


/* =========================================================
   TOAST
========================================================= */

function toast(text){

  const box =
    $("toast");

  if(!box)
    return;

  box.textContent =
    String(text);

  box.classList.add("show");

  clearTimeout(toastTimer);

  toastTimer =
    setTimeout(() => {

      box.classList.remove("show");

    },1800);

}


/* =========================================================
   MODAL
========================================================= */

function closeModal(){

  // Disconnect the Web Audio graph before destroying a music modal.
  // This prevents stale MediaElementSource/Analyser nodes from keeping
  // the previous audio element alive after the modal is closed.
  releaseSpectrumNodes(false);

  const modal =
    $("modal");

  const box =
    $("modalBox");

  if(modal)
    modal.classList.remove("show");

  if(box)
    box.innerHTML = "";

  currentModal = null;

}


function openModal(type){

  if(!type)
    return;

  currentModal = type;

  let html = "";

  try{

    switch(type){

      case "calendar":
        html = calendarHTML();
        break;

      case "system":
        html = systemHTML();
        break;

      case "music":
        html = musicHTML();
        break;

      case "files":
        html = filesHTML();
        break;

      case "photos":
        html = photosHTML();
        break;

      case "float":
        html = floatHTML();
        break;

      case "translator":
        html = translatorHTML();
        break;

      case "tools":
        html = toolsHTML();
        break;

      case "game":
        html = gameHTML();
        break;

      case "notice":
        html = noticeHTML();
        break;

      case "settings":
        html = settingsHTML();
        break;

      case "profile":
        html = profileHTML();
        break;

      case "search":
        html = searchHTML();
        break;

      case "about":
        html = aboutHTML();
        break;

      case "serverApi":
        html = serverApiHTML();
        break;

      case "telegram":
        openTelegramCommunity();
        currentModal = null;
        return;

      case "control":
        html = controlHTML();
        break;

      case "stopwatch":
        html = stopwatchHTML();
        break;

      case "game2048":
        html = game2048HTML();
        break;

      default:
        currentModal = null;
        return;

    }

    const box =
      $("modalBox");

    const modal =
      $("modal");

    if(!box || !modal)
      return;

    box.innerHTML = html;
    modal.classList.add("show");

    afterModalOpen(type);

  }catch(err){

    console.error(
      "Modal error:",
      err
    );

    toast(
      state.language === "zh"
        ? "模块加载失败"
        : "Module failed"
    );

  }

}


function afterModalOpen(type){

  if(type === "notice")
    renderAnnouncements();

  if(type === "control")
    syncControlUI();

  if(type === "stopwatch")
    renderStopwatch();

  if(type === "game2048")
    render2048();

  if(type === "music"){

    renderPlaylist();

    const audio =
      $("audioPlayer");

    if(audio){

      audio.addEventListener(
        "timeupdate",
        updateMusicProgress
      );

      audio.addEventListener(
        "loadedmetadata",
        updateMusicDuration
      );

      audio.addEventListener(
        "play",
        () => {

          $("albumVisual")
            ?.classList.add("playing");

          initSpectrum(audio);
          try{ audioContext?.resume(); }catch(e){}

          const track =
            state.musicTracks[
              state.currentTrack
            ];

          if($("musicStatus"))
            $("musicStatus").textContent =
              track
                ? track.name
                : t("music");

        }
      );

      audio.addEventListener(
        "pause",
        () => {

          $("albumVisual")
            ?.classList.remove("playing");
          stopSpectrum();

        }
      );

      audio.addEventListener(
        "ended",
        nextTrack
      );

    }

  }

  if(type === "files")
    renderFiles();

  if(type === "photos")
    renderPhotos();

  if(type === "translator"){

    if($("sourceLanguage"))
      $("sourceLanguage").value = "zh";

    if($("targetLanguage"))
      $("targetLanguage").value = "en";

  }

}


/* =========================================================
   CALENDAR
========================================================= */

function calendarHTML(){

  return `
    <div class="modalHead">
      <h2>🕐 ${t("timeCenter")}</h2>
      <button class="close" data-close>×</button>
    </div>

    <div class="modalBody">

      <div class="section" style="text-align:center">

        <div
          id="modalClock"
          style="font-size:48px;font-weight:900">
          ${escapeHtml(
            $("heroTime")?.textContent || ""
          )}
        </div>

        <div class="muted" style="margin-top:8px">
          ${escapeHtml(
            $("heroDate")?.textContent || ""
          )}
        </div>

      </div>

      <button
        class="btn"
        style="width:100%"
        data-close>
        ${t("complete")}
      </button>

    </div>
  `;

}


/* =========================================================
   SYSTEM
========================================================= */

function systemHTML(){

  return `
    <div class="modalHead">
      <h2>⚡ ${t("systemStatus")}</h2>
      <button class="close" data-close>×</button>
    </div>

    <div class="modalBody">

      <div class="section">
        <div class="sectionTitle">
          🔋 ${t("systemBattery")}
        </div>

        <div
          id="modalBattery"
          style="font-size:36px;font-weight:900">
          ${escapeHtml(
            $("systemBattery")?.textContent || "—"
          )}
        </div>
      </div>

      <div class="section">
        <div class="sectionTitle">
          📡 Network
        </div>

        <div class="muted">
          ${
            navigator.onLine
              ? t("online")
              : t("offline")
          }
        </div>
      </div>

      <div class="section">
        <div class="sectionTitle">
          🧠 ${t("performance")}
        </div>

        <div class="muted">
          ${
            state.performance
              ? t("enabled")
              : t("disabled")
          }
        </div>
      </div>

      <button
        class="btn"
        style="width:100%"
        data-close>
        ${t("complete")}
      </button>

    </div>
  `;

}


/* =========================================================
   MUSIC HTML
========================================================= */

function musicHTML(){

  const current =
    state.currentTrack >= 0
      ? state.musicTracks[state.currentTrack]
      : null;

  return `
    <div class="modalHead">

      <h2>🎵 ${t("musicCenter")}</h2>

      <button class="close" data-close>×</button>

    </div>

    <div class="modalBody">

      <div class="musicHero">

        <div class="albumWrap">

          <div
            class="album"
            id="albumVisual">
            ♪
          </div>

        </div>

        <div
          class="musicName"
          id="musicTitle">
          ${
            current
              ? escapeHtml(current.name)
              : "ZEN MUSIC"
          }
        </div>

        <div
          class="musicStatus"
          id="musicStatus">
          ${
            current
              ? escapeHtml(formatSize(current.size))
              : t("musicEmpty")
          }
        </div>

        <div class="musicProgress">

          <input
            id="musicSeek"
            type="range"
            min="0"
            max="100"
            value="0">

          <div class="musicTimes">

            <span id="musicCurrent">
              0:00
            </span>

            <span id="musicDuration">
              0:00
            </span>

          </div>

        </div>

        <canvas
          id="spectrumCanvas"
          class="spectrumCanvas"
          aria-label="Music spectrum">
        </canvas>

        <div class="musicControls">

          <button
            class="musicBtn"
            data-music="prev">
            ⏮
          </button>

          <button
            class="musicBtn main"
            data-music="play">
            ▶
          </button>

          <button
            class="musicBtn"
            data-music="next">
            ⏭
          </button>

        </div>

        <audio
          id="audioPlayer"
          preload="metadata">
        </audio>

      </div>

      <div class="section">

        <div class="sectionTitle">
          ${t("chooseMusic")}
        </div>

        <input
          id="musicInput"
          type="file"
          accept="audio/*"
          multiple>

      </div>

      <div
        class="musicPlaylist"
        id="musicPlaylist">
      </div>

      <button
        class="btn"
        style="width:100%;margin-top:12px"
        data-close>
        ${t("complete")}
      </button>

    </div>
  `;

}


/* =========================================================
   MUSIC
========================================================= */

function initSpectrum(audio){
  const canvas=$("spectrumCanvas");
  if(!canvas || !audio) return;
  try{
    if(!audioContext || audioContext.state === "closed")
      audioContext=new (window.AudioContext||window.webkitAudioContext)();

    /* 每个 HTMLMediaElement 只能创建一次 MediaElementSource。
       Modal 重建后会得到新的 audio 元素，因此必须重新绑定。 */
    if(spectrumAudio !== audio || !audioSourceNode){
      releaseSpectrumNodes(false);

      audioSourceNode=audioContext.createMediaElementSource(audio);
      audioAnalyser=audioContext.createAnalyser();
      audioAnalyser.fftSize=128;
      audioSourceNode.connect(audioAnalyser);
      audioAnalyser.connect(audioContext.destination);
      spectrumAudio=audio;
    }

    drawSpectrum();
  }catch(e){
    console.warn("Spectrum unavailable",e);
  }
}
function drawSpectrum(){
  const canvas=$("spectrumCanvas");
  if(!canvas || !audioAnalyser) return;
  const dpr=Math.max(1,window.devicePixelRatio||1);
  const rect=canvas.getBoundingClientRect();
  canvas.width=Math.max(1,Math.floor(rect.width*dpr));
  canvas.height=Math.max(1,Math.floor(rect.height*dpr));
  const ctx=canvas.getContext("2d");
  if(!ctx) return;
  const data=new Uint8Array(audioAnalyser.frequencyBinCount);
  audioAnalyser.getByteFrequencyData(data);
  ctx.clearRect(0,0,canvas.width,canvas.height);
  const w=canvas.width/data.length;
  for(let i=0;i<data.length;i++){
    const h=(data[i]/255)*canvas.height;
    ctx.fillStyle=`rgba(110,125,255,${0.18+data[i]/400})`;
    ctx.fillRect(i*w,canvas.height-h,Math.max(1,w-1),h);
  }
  spectrumFrame=requestAnimationFrame(drawSpectrum);
}
function stopSpectrum(){
  if(spectrumFrame){
    cancelAnimationFrame(spectrumFrame);
    spectrumFrame=0;
  }
}

function releaseSpectrumNodes(closeContext=false){
  stopSpectrum();

  try{ audioSourceNode?.disconnect(); }catch(e){}
  try{ audioAnalyser?.disconnect(); }catch(e){}

  audioSourceNode=null;
  audioAnalyser=null;
  spectrumAudio=null;

  if(closeContext && audioContext){
    try{ audioContext.close(); }catch(e){}
    audioContext=null;
  }
}

function loadMusicFiles(files){

  const list = Array.from(files || []);
  if(!list.length) return;

  const MAX_AUDIO_BYTES = 200 * 1024 * 1024;
  const MAX_AUDIO_COUNT = 50;
  let accepted = 0;

  list.forEach(file => {
    if(accepted >= MAX_AUDIO_COUNT || state.musicTracks.length >= MAX_AUDIO_COUNT) return;

    if(
      !file.type.startsWith("audio/") ||
      file.size > MAX_AUDIO_BYTES
    )
      return;

    state.musicTracks.push({
      name:file.name,
      size:file.size,
      url:URL.createObjectURL(file),
      file:file
    });

  });

  if(
    state.currentTrack < 0 &&
    state.musicTracks.length
  ){

    state.currentTrack = 0;

  }

  renderPlaylist();

  if(state.currentTrack >= 0)
    loadTrack(state.currentTrack);

  toast(
    state.language === "zh"
      ? "音乐已载入"
      : "Music loaded"
  );

}


function renderPlaylist(){

  const box =
    $("musicPlaylist");

  if(!box)
    return;

  box.innerHTML = "";

  if(!state.musicTracks.length){

    box.innerHTML =
      `<div class="section">
        <div class="muted">
          ${t("musicEmpty")}
        </div>
      </div>`;

    return;

  }

  state.musicTracks.forEach(
    (track,index) => {

      const div =
        document.createElement("div");

      div.className = "track";

      div.innerHTML = `
        <div class="trackIcon">
          ${
            index === state.currentTrack
              ? "▶"
              : "🎵"
          }
        </div>

        <div class="trackInfo">

          <div class="trackName">
            ${escapeHtml(track.name)}
          </div>

          <div class="trackMeta">
            ${formatSize(track.size)}
          </div>

        </div>

        <button
          class="btn"
          style="padding:8px 11px"
          data-track="${index}">
          ▶
        </button>
      `;

      box.appendChild(div);

    }
  );

}


function loadTrack(index){

  if(!state.musicTracks[index])
    return;

  const audio =
    $("audioPlayer");

  if(!audio)
    return;

  state.currentTrack = index;

  const track =
    state.musicTracks[index];

  try{

    audio.src = track.url;
    audio.load();

  }catch(err){

    console.warn(
      "Audio load failed",
      err
    );

  }

  if($("musicTitle"))
    $("musicTitle").textContent =
      track.name;

  if($("musicStatus"))
    $("musicStatus").textContent =
      formatSize(track.size);

  renderPlaylist();

}


function playPause(){

  const audio =
    $("audioPlayer");

  if(
    !audio ||
    !audio.src
  ){

    toast(t("musicEmpty"));
    return;

  }

  if(audio.paused){

    audio.play()
      .catch(() => {

        toast(
          state.language === "zh"
            ? "请点击播放按钮"
            : "Tap play to start"
        );

      });

  }else{

    audio.pause();

  }

}


function nextTrack(){

  if(!state.musicTracks.length)
    return;

  let i =
    state.currentTrack + 1;

  if(i >= state.musicTracks.length)
    i = 0;

  loadTrack(i);

  const audio =
    $("audioPlayer");

  if(audio)
    audio.play().catch(()=>{});

}


function previousTrack(){

  if(!state.musicTracks.length)
    return;

  let i =
    state.currentTrack - 1;

  if(i < 0)
    i = state.musicTracks.length - 1;

  loadTrack(i);

  const audio =
    $("audioPlayer");

  if(audio)
    audio.play().catch(()=>{});

}


function updateMusicProgress(){

  const audio =
    $("audioPlayer");

  const seek =
    $("musicSeek");

  if(!audio || !seek)
    return;

  if(
    Number.isFinite(audio.duration) &&
    audio.duration > 0
  ){

    seek.value =
      audio.currentTime /
      audio.duration *
      100;

  }

  if($("musicCurrent"))
    $("musicCurrent").textContent =
      formatTime(audio.currentTime);

}


function updateMusicDuration(){

  const audio =
    $("audioPlayer");

  if(!audio)
    return;

  if($("musicDuration"))
    $("musicDuration").textContent =
      formatTime(audio.duration);

}


function formatTime(sec){

  if(!Number.isFinite(sec))
    return "0:00";

  const min =
    Math.floor(sec / 60);

  const s =
    Math.floor(sec % 60)
      .toString()
      .padStart(2,"0");

  return min + ":" + s;

}


/* =========================================================
   FILES
========================================================= */

function filesHTML(){

  return `
    <div class="modalHead">

      <h2>📁 ${t("files")}</h2>

      <button class="close" data-close>×</button>

    </div>

    <div class="modalBody">

      <div class="section">

        <div class="sectionTitle">
          ${t("chooseFiles")}
        </div>

        <input
          id="fileInput"
          type="file"
          multiple>

        <input
          id="fileSearch"
          class="input fileSearch"
          placeholder="${t("searchApp")}"
          autocomplete="off">

      </div>

      <div
        class="fileList"
        id="fileList">
      </div>

      <button
        class="btn"
        style="width:100%;margin-top:12px"
        data-close>
        ${t("complete")}
      </button>

    </div>
  `;

}


function loadFiles(files){

  const list = Array.from(files || []);
  const MAX_FILE_BYTES = 200 * 1024 * 1024;
  const MAX_FILE_COUNT = 200;

  state.files =
    list
      .filter(file => file.size <= MAX_FILE_BYTES)
      .slice(0, MAX_FILE_COUNT)
      .map(file => ({
      name:file.name,
      size:file.size,
      type:file.type,
      lastModified:file.lastModified
    }));

  renderFiles();

}


function renderFiles(filter=""){

  const box =
    $("fileList");

  if(!box)
    return;

  box.innerHTML = "";

  const q =
    String(filter)
      .trim()
      .toLowerCase();

  const files =
    state.files.filter(file =>
      !q ||
      file.name
        .toLowerCase()
        .includes(q)
    );

  if(!files.length){

    box.innerHTML = `
      <div class="section">
        <div class="muted">
          ${
            state.files.length
              ? t("noResult")
              : t("filesEmpty")
          }
        </div>
      </div>
    `;

    return;

  }

  files.forEach(file => {

    const item =
      document.createElement("div");

    item.className =
      "fileItem";

    item.innerHTML = `
      <div class="fileIcon">
        ${fileIcon(file.type || "")}
      </div>

      <div class="fileInfo">

        <div class="fileName">
          ${escapeHtml(file.name)}
        </div>

        <div class="fileMeta">
          ${formatSize(file.size)}
          ·
          ${escapeHtml(file.type || "file")}
        </div>

      </div>
    `;

    box.appendChild(item);

  });

}


function fileIcon(type){

  if(type.startsWith("image/"))
    return "🖼️";

  if(type.startsWith("audio/"))
    return "🎵";

  if(type.startsWith("video/"))
    return "🎬";

  if(type.includes("pdf"))
    return "📕";

  if(
    type.includes("zip") ||
    type.includes("compressed")
  )
    return "🗜️";

  if(type.includes("text"))
    return "📝";

  return "📄";

}


/* =========================================================
   PHOTOS
========================================================= */

function photosHTML(){

  return `
    <div class="modalHead">

      <h2>🖼️ ${t("photos")}</h2>

      <button class="close" data-close>×</button>

    </div>

    <div class="modalBody">

      <div class="section">

        <div class="sectionTitle">
          ${t("choosePhotos")}
        </div>

        <input
          id="photoInput"
          type="file"
          accept="image/*"
          multiple>

      </div>

      <div class="photoToolbar">

        <button
          class="btn"
          id="photoClear">
          ${t("clear")}
        </button>

        <button
          class="btn"
          id="photoCount">
          0
        </button>

      </div>

      <div
        class="photoGrid"
        id="photoGrid">
      </div>

      <button
        class="btn"
        style="width:100%;margin-top:15px"
        data-close>
        ${t("complete")}
      </button>

    </div>
  `;

}


function loadPhotos(files){

  const list = Array.from(files || []);
  const MAX_IMAGE_BYTES = 50 * 1024 * 1024;
  const MAX_IMAGE_COUNT = 100;

  list.forEach(file => {

    if(
      !file.type.startsWith("image/") ||
      file.size > MAX_IMAGE_BYTES ||
      state.photos.length >= MAX_IMAGE_COUNT
    )
      return;

    const url =
      URL.createObjectURL(file);

    state.photos.push({
      name:file.name,
      size:file.size,
      url:url
    });

  });

  renderPhotos();

}


function renderPhotos(){

  const grid =
    $("photoGrid");

  if(!grid)
    return;

  grid.innerHTML = "";

  if($("photoCount"))
    $("photoCount").textContent =
      state.photos.length;

  if(!state.photos.length){

    grid.innerHTML = `
      <div
        class="section"
        style="grid-column:1/-1">
        <div class="muted">
          ${t("photosEmpty")}
        </div>
      </div>
    `;

    return;

  }

  state.photos.forEach(
    (photo,index) => {

      const div =
        document.createElement("div");

      div.className =
        "photoItem";

      const img =
        document.createElement("img");

      img.src = photo.url;
      img.alt = photo.name;
      img.loading = "lazy";

      img.addEventListener(
        "click",
        () => openViewer(photo.url)
      );

      const del =
        document.createElement("button");

      del.textContent = "×";

      del.addEventListener(
        "click",
        e => {

          e.stopPropagation();

          try{
            URL.revokeObjectURL(photo.url);
          }catch(err){}

          state.photos.splice(index,1);

          renderPhotos();

        }
      );

      div.appendChild(img);
      div.appendChild(del);

      grid.appendChild(div);

    }
  );

}


function openViewer(url){

  if(!$("viewer") || !$("viewerImage"))
    return;

  $("viewerImage").src = url;

  $("viewer").classList.add("show");

}


function closeViewer(){

  if($("viewer"))
    $("viewer").classList.remove("show");

  if($("viewerImage"))
    $("viewerImage").src = "";

}


/* =========================================================
   FLOAT ENGINE
========================================================= */

function floatHTML(){

  return `
    <div class="modalHead">
      <h2>✨ ${t("float")} V4</h2>
      <button class="close" data-close>×</button>
    </div>

    <div class="modalBody">

      <div class="section">
        <div class="sectionTitle">${t("floatText")}</div>
        <input id="floatInput" class="input" value="${escapeHtml(state.floatText)}" maxlength="100">
        <button class="btn primary" style="width:100%;margin-top:10px" id="saveFloat">${t("save")}</button>
      </div>

      <div class="section">
        <div class="sectionTitle">${t("floatMode")}</div>
        <select id="floatModeSelect">
          <option value="rise" ${state.floatMode==="rise"?"selected":""}>${t("floatModeRise")}</option>
          <option value="drift" ${state.floatMode==="drift"?"selected":""}>${t("floatModeDrift")}</option>
          <option value="side" ${state.floatMode==="side"?"selected":""}>${t("floatModeSide")}</option>
          <option value="pulse" ${state.floatMode==="pulse"?"selected":""}>${t("floatModePulse")}</option>
        </select>
      </div>

      <div class="section floatSettings">
        <div class="floatSettingRow"><span>${t("floatSpeed")}</span><b id="floatSpeedValue">${Number(state.floatSpeed).toFixed(1)}×</b></div>
        <input id="floatSpeed" type="range" min="0.4" max="2" step="0.1" value="${state.floatSpeed}">

        <div class="floatSettingRow"><span>${t("floatDensity")}</span><b id="floatDensityValue">${Number(state.floatDensity).toFixed(1)}×</b></div>
        <input id="floatDensity" type="range" min="0.5" max="3" step="0.1" value="${state.floatDensity}">

        <div class="floatSettingRow"><span>${t("floatOpacity")}</span><b id="floatOpacityValue">${Math.round(state.floatOpacity*100)}%</b></div>
        <input id="floatOpacity" type="range" min="0.15" max="1" step="0.05" value="${state.floatOpacity}">

        <div class="floatSettingRow"><span>${t("floatSize")}</span><b id="floatSizeValue">${state.floatSize}px</b></div>
        <input id="floatSize" type="range" min="10" max="32" step="1" value="${state.floatSize}">

        <div class="floatSettingRow"><span>${t("floatMax")}</span><b id="floatMaxValue">${state.floatMax}</b></div>
        <input id="floatMax" type="range" min="4" max="40" step="1" value="${state.floatMax}">
      </div>

      <div class="section">
        <div class="sectionTitle">✨ ${t("enabled")}</div>
        <button class="toggle ${state.floatEnabled ? "on" : ""}" id="floatToggle"><i></i></button>
        <div class="muted">${state.floatEnabled ? t("enabled") : t("disabled")}</div>
      </div>

      <div class="row">
        <button class="btn" id="floatPreview">✨ ${t("floatPreview")}</button>
        <button class="btn" id="floatReset">↺ ${t("floatReset")}</button>
      </div>

      <button class="btn" style="width:100%;margin-top:12px" data-close>${t("complete")}</button>
    </div>
  `;
}

function saveFloat(){

  const input =
    $("floatInput");

  if(!input)
    return;

  const value =
    input.value.trim();

  if(!value){

    toast(
      state.language === "zh"
        ? "请输入浮字"
        : "Enter floating text"
    );

    return;

  }

  state.floatText = value.slice(0,100);
  state.floatEnabled = true;
  normalizeFloatSettings();
  saveState();
  scheduleFloatEngine();
  toast(t("floatSavedV4"));
  openModal("float");

}


function normalizeFloatSettings(){

  if(!["rise","drift","side","pulse"].includes(state.floatMode))
    state.floatMode = "rise";

  state.floatSpeed = Math.min(2, Math.max(.4, Number(state.floatSpeed) || 1));
  state.floatDensity = Math.min(3, Math.max(.5, Number(state.floatDensity) || 1));
  state.floatOpacity = Math.min(1, Math.max(.15, Number(state.floatOpacity) || .55));
  state.floatSize = Math.min(32, Math.max(10, Math.round(Number(state.floatSize) || 16)));
  state.floatMax = Math.min(40, Math.max(4, Math.round(Number(state.floatMax) || 18)));
}

function updateFloatControlLabels(){
  const map = {
    floatSpeed:["floatSpeedValue", v => Number(v).toFixed(1)+"×"],
    floatDensity:["floatDensityValue", v => Number(v).toFixed(1)+"×"],
    floatOpacity:["floatOpacityValue", v => Math.round(Number(v)*100)+"%"],
    floatSize:["floatSizeValue", v => Math.round(Number(v))+"px"],
    floatMax:["floatMaxValue", v => Math.round(Number(v))]
  };
  Object.entries(map).forEach(([id,[label,fmt]])=>{
    const input=$(id), out=$(label);
    if(input && out) out.textContent=fmt(input.value);
  });
}

function saveFloatSettingsFromUI(){
  const mode=$("floatModeSelect");
  if(mode) state.floatMode=mode.value;
  ["floatSpeed","floatDensity","floatOpacity","floatSize","floatMax"].forEach(id=>{
    const input=$(id);
    if(input){
      const key=id;
      state[key]=Number(input.value);
    }
  });
  normalizeFloatSettings();
  saveState();
  scheduleFloatEngine();
}

/* =========================================================
   TRANSLATOR
========================================================= */

function translatorHTML(){

  return `
    <div class="modalHead">

      <h2>🌐 ${t("translator")}</h2>

      <button class="close" data-close>×</button>

    </div>

    <div class="modalBody">

      <div class="section">

        <div class="row">

          <select id="sourceLanguage">

            <option value="zh">
              中文
            </option>

            <option value="en">
              English
            </option>

          </select>

          <select id="targetLanguage">

            <option value="en">
              English
            </option>

            <option value="zh">
              中文
            </option>

          </select>

          <button
            class="btn"
            id="swapLanguages"
            type="button"
            title="Swap languages">
            ⇄
          </button>

        </div>

      </div>

      <textarea
        id="translateInput"
        placeholder="${t("sourceText")}">
      </textarea>

      <button
        class="btn primary"
        style="width:100%;margin-top:10px"
        id="translateBtn">
        🌐 ${t("translate")}
      </button>

      <div class="section" style="margin-top:12px">

        <div class="sectionTitle">
          ${t("result")}
        </div>

        <div
          id="translateResult"
          style="min-height:60px;line-height:1.7">
        </div>

      </div>

      <div class="muted">
        ${t("localTranslate")}
      </div>

      <button
        class="btn"
        style="width:100%;margin-top:12px"
        id="translateClear">
        ${t("clear")}
      </button>

    </div>
  `;

}


const CN_EN = {

  "你好":"hello",
  "你好啊":"hello",
  "谢谢":"thank you",
  "谢谢你":"thank you",
  "再见":"goodbye",
  "早上好":"good morning",
  "晚上好":"good evening",
  "晚安":"good night",
  "欢迎":"welcome",
  "朋友":"friend",
  "音乐":"music",
  "照片":"photo",
  "文件":"file",
  "设置":"settings",
  "系统":"system",
  "时间":"time",
  "天气":"weather",
  "游戏":"game",
  "翻译":"translate",
  "电脑":"computer",
  "手机":"phone",
  "中国":"China",
  "美国":"United States",
  "今天":"today",
  "明天":"tomorrow",
  "昨天":"yesterday",
  "很好":"very good",
  "好的":"okay",
  "是的":"yes",
  "不是":"no",
  "我":"I",
  "你":"you",
  "他":"he",
  "她":"she",
  "我们":"we",
  "他们":"they",
  "喜欢":"like",
  "爱":"love",
  "学习":"study",
  "工作":"work",
  "回家":"go home",
  "多少钱":"how much",
  "为什么":"why",
  "什么":"what",
  "哪里":"where",
  "谁":"who",
  "怎么样":"how",
  "可以":"can",
  "不可以":"cannot",
  "你好世界":"hello world",
  "我爱你":"I love you",
  "你好吗":"how are you",
  "我很好":"I am very good",
  "再见了":"goodbye",
  "请":"please",
  "对不起":"sorry",
  "没关系":"it is okay",
  "帮助":"help",
  "欢迎回来":"welcome back",
  "早安":"good morning",
  "下午好":"good afternoon",
  "晚上":"evening",
  "明白了":"understood",
  "不知道":"I don't know",
  "我不知道":"I don't know",
  "现在":"now",
  "这里":"here",
  "那里":"there",
  "打开":"open",
  "关闭":"close",
  "开始":"start",
  "停止":"stop",
  "保存":"save",
  "删除":"delete",
  "是":"yes",
  "否":"no"

};


const EN_CN = {

  "hello":"你好",
  "hi":"你好",
  "thank you":"谢谢你",
  "thanks":"谢谢",
  "goodbye":"再见",
  "good morning":"早上好",
  "good evening":"晚上好",
  "good night":"晚安",
  "welcome":"欢迎",
  "friend":"朋友",
  "music":"音乐",
  "photo":"照片",
  "file":"文件",
  "settings":"设置",
  "system":"系统",
  "time":"时间",
  "weather":"天气",
  "game":"游戏",
  "translate":"翻译",
  "computer":"电脑",
  "phone":"手机",
  "China":"中国",
  "United States":"美国",
  "today":"今天",
  "tomorrow":"明天",
  "yesterday":"昨天",
  "very good":"很好",
  "okay":"好的",
  "yes":"是的",
  "no":"不是",
  "I":"我",
  "you":"你",
  "he":"他",
  "she":"她",
  "we":"我们",
  "they":"他们",
  "like":"喜欢",
  "love":"爱",
  "study":"学习",
  "work":"工作",
  "why":"为什么",
  "what":"什么",
  "where":"哪里",
  "who":"谁",
  "how":"怎么样",
  "hello world":"你好世界",
  "I love you":"我爱你",
  "how are you":"你好吗",
  "I am very good":"我很好",
  "please":"请",
  "sorry":"对不起",
  "it is okay":"没关系",
  "help":"帮助",
  "welcome back":"欢迎回来",
  "good afternoon":"下午好",
  "understood":"明白了",
  "I don't know":"我不知道",
  "now":"现在",
  "here":"这里",
  "there":"那里",
  "open":"打开",
  "close":"关闭",
  "start":"开始",
  "stop":"停止",
  "save":"保存",
  "delete":"删除"

};


function localTranslate(text,from,to){

  const source = String(text || "").trim();

  if(!source)
    return "";

  if(from === to)
    return source;

  const dict = from === "zh" ? CN_EN : EN_CN;
  const normalized = source.toLowerCase();

  const exactKey = Object.keys(dict).find(
    key => key.toLowerCase() === normalized
  );

  if(exactKey)
    return dict[exactKey];

  let result = source;
  const keys = Object.keys(dict).sort((a,b) => b.length-a.length);

  for(const key of keys){

    const escaped = escapeRegExp(key);
    let regex;

    if(from === "en"){
      // Match English words/phrases without requiring a word boundary
      // at punctuation, so "hello!" and "thank you," also work.
      regex = new RegExp(
        "(^|[^A-Za-z])(" + escaped + ")(?=$|[^A-Za-z])",
        "gi"
      );

      result = result.replace(regex, (m, before) => before + dict[key]);

    }else{

      regex = new RegExp(escaped, "g");
      result = result.replace(regex, dict[key]);

    }
  }

  if(result === source){
    return from === "zh"
      ? "本地模式：" + source
      : "Local mode: " + source;
  }

  return result;

}


/* =========================================================
   TOOLS
========================================================= */

function toolsHTML(){

  return `
    <div class="modalHead">

      <h2>🧮 ${t("tools")}</h2>

      <button class="close" data-close>×</button>

    </div>

    <div class="modalBody">

      <div class="section">

        <div class="sectionTitle">
          ${t("random")}
        </div>

        <div class="row">

          <input
            class="input"
            id="randomMin"
            value="1"
            type="number">

          <input
            class="input"
            id="randomMax"
            value="100"
            type="number">

        </div>

        <button
          class="btn primary"
          style="width:100%;margin-top:10px"
          id="randomBtn">
          ${t("random")}
        </button>

        <div
          id="randomResult"
          style="
            font-size:42px;
            font-weight:900;
            text-align:center;
            margin-top:15px">
          ?
        </div>

      </div>

      <div class="section">

        <div class="sectionTitle">
          ${t("timestamp")}
        </div>

        <div
          id="timestamp"
          style="font-size:22px;font-weight:800">
          ${Date.now()}
        </div>

        <button
          class="btn"
          style="margin-top:10px"
          id="copyTimestamp">
          ${t("copied")}
        </button>

      </div>

      <button
        class="btn"
        style="width:100%"
        data-close>
        ${t("complete")}
      </button>

    </div>
  `;

}


function generateRandom(){

  const min =
    Number($("randomMin")?.value);

  const max =
    Number($("randomMax")?.value);

  if(
    !Number.isFinite(min) ||
    !Number.isFinite(max) ||
    min > max
  ){

    toast(t("rangeError"));
    return;

  }

  const n =
    Math.floor(
      Math.random() *
      (max-min+1)
    ) + min;

  if($("randomResult"))
    $("randomResult").textContent = n;

}


/* =========================================================
   CALCULATOR V19
========================================================= */

let calculatorExpression = "";

function calculatorHTML(){
  calculatorExpression = "";
  return `
    <div class="modalHead">
      <h2>🧾 ${t("calculator")}</h2>
      <button class="close" data-close>×</button>
    </div>
    <div class="modalBody">
      <div class="section">
        <input id="calcDisplay" class="input" readonly value="" aria-label="Calculator display" style="font-size:28px;text-align:right;font-weight:800">
      </div>
      <div class="controlGrid" id="calcKeys">
        ${["C","⌫","%","÷","7","8","9","×","4","5","6","−","1","2","3","+","0",".","(",")","="]
          .map(k=>`<button class="btn" type="button" data-calc="${escapeHtml(k)}">${escapeHtml(k)}</button>`).join("")}
      </div>
      <button class="btn" style="width:100%;margin-top:12px" data-close>${t("complete")}</button>
    </div>`;
}

function calculatorInput(key){
  const display=$("calcDisplay");
  if(!display) return;
  if(key==="C"){ calculatorExpression=""; }
  else if(key==="⌫"){ calculatorExpression=calculatorExpression.slice(0,-1); }
  else if(key==="="){
    const expr=calculatorExpression.replace(/×/g,"*").replace(/÷/g,"/").replace(/−/g,"-").replace(/%/g,"/100");
    if(!/^[0-9+\-*/(). %]+$/.test(expr)){ toast(state.language==="zh"?"表达式无效":"Invalid expression"); return; }
    try{
      const value=Function("\"use strict\";return ("+expr+")")();
      if(!Number.isFinite(value)) throw new Error();
      calculatorExpression=String(Math.round(value*1e10)/1e10);
    }catch(e){ toast(state.language==="zh"?"计算失败":"Calculation failed"); return; }
  }else{
    if(calculatorExpression.length>=60) return;
    calculatorExpression += key;
  }
  display.value=calculatorExpression;
}

/* =========================================================
   GAME
========================================================= */

function gameHTML(){

  gameTarget =
    Math.floor(
      Math.random()*100
    ) + 1;

  gameAttempts = 0;

  return `
    <div class="modalHead">

      <h2>🎮 ${t("guess")}</h2>

      <button class="close" data-close>×</button>

    </div>

    <div class="modalBody">

      <div class="section">

        <div class="sectionTitle">
          ${t("guess")}
        </div>

        <div class="muted">
          1 - 100
        </div>

      </div>

      <input
        class="input"
        id="guessInput"
        type="number"
        min="1"
        max="100"
        placeholder="${t("inputNumber")}">

      <button
        class="btn primary"
        style="width:100%;margin-top:10px"
        id="guessBtn">
        ${t("guess")}
      </button>

      <div
        id="guessResult"
        style="
          text-align:center;
          font-size:20px;
          font-weight:800;
          margin:20px 0">
        ${t("guessStart")}
      </div>

      <button
        class="btn"
        style="width:100%"
        id="newGameBtn">
        ${t("guessStart")}
      </button>

    </div>
  `;

}


function makeGuess(){

  const input =
    $("guessInput");

  const result =
    $("guessResult");

  if(!input || !result)
    return;

  const n =
    Number(input.value);

  if(
    !Number.isFinite(n) ||
    n < 1 ||
    n > 100
  ){

    toast(t("inputNumber"));
    return;

  }

  gameAttempts++;

  if(n === gameTarget){

    result.textContent =
      "🎉 " +
      t("correct") +
      " · " +
      gameAttempts;

    return;

  }

  result.textContent =
    n < gameTarget
      ? "⬆️ " + t("bigger")
      : "⬇️ " + t("smaller");

}


function newGame(){

  gameTarget =
    Math.floor(
      Math.random()*100
    ) + 1;

  gameAttempts = 0;

  if($("guessInput"))
    $("guessInput").value = "";

  if($("guessResult"))
    $("guessResult").textContent =
      t("guessStart");

}


/* =========================================================
   SERVER API
========================================================= */

let serverAnnouncements = null;

function getApiBase(){
  const raw = String(state.serverApiUrl || "https://zenos-91.onrender.com/api").trim();
  if(!raw) return "https://zenos-91.onrender.com/api";
  return raw.replace(/\/+$/, "");
}

function apiUrl(path){
  const clean = String(path || "").replace(/^\/+/, "");
  return getApiBase() + "/" + clean;
}

async function apiRequest(path, options = {}){
  if(!state.serverApiEnabled) throw new Error("Server API disabled");
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try{
    const response = await fetch(apiUrl(path), {
      method: options.method || "GET",
      headers:{"Accept":"application/json", ...(options.body ? {"Content-Type":"application/json"} : {})},
      body: options.body ? JSON.stringify(options.body) : undefined,
      signal:controller.signal,
      credentials:"same-origin",
      cache:"no-store"
    });
    if(!response.ok) throw new Error("HTTP " + response.status);
    const type = response.headers.get("content-type") || "";
    return type.includes("application/json") ? await response.json() : await response.text();
  }finally{
    clearTimeout(timer);
  }
}

async function testServerApi(){
  try{
    await apiRequest("health");
    toast(t("apiOnline"));
    return true;
  }catch(err){
    console.warn("ZEN OS server API unavailable:", err);
    toast(t("apiOffline"));
    return false;
  }
}

async function syncServerAnnouncements(){
  if(!state.serverApiEnabled || !state.serverApiAnnouncements) return;
  try{
    const data = await apiRequest("announcements?lang=" + encodeURIComponent(state.language));
    const list = Array.isArray(data) ? data : (data && Array.isArray(data.announcements) ? data.announcements : []);
    const normalized = list.map((item, index) => ({
      id:String(item.id ?? ("server-" + index)),
      title:String(item.title ?? ""),
      content:String(item.content ?? item.message ?? ""),
      date:String(item.date ?? item.createdAt ?? "").slice(0,40),
      pinned:item.pinned === true,
      isNew:item.isNew === true
    })).filter(item => item.title || item.content);
    serverAnnouncements = normalized;
    updateAnnouncementBar();
    if(currentModal === "notice") renderAnnouncements();
  }catch(err){
    console.warn("ZEN OS announcement API unavailable; using local announcements.", err);
  }
}

/* =========================================================
   NOTICE
========================================================= */

function getAnnouncements(){

  if(Array.isArray(serverAnnouncements) && serverAnnouncements.length)
    return serverAnnouncements;

  return [
    {
      id:"v194",
      title: state.language === "zh" ? "ZEN OS V19 · 浮字引擎 V4" : "ZEN OS V19 · Floating Text Engine V4",
      content: state.language === "zh"
        ? "浮字引擎 V4 已上线：支持上浮、漂移、横向、脉冲四种模式，并新增速度、频率、透明度、字号、数量控制。所有设置均保存在本地。"
        : "Floating Text Engine V4 is live: Rise, Drift, Side and Pulse modes plus speed, density, opacity, size and item-limit controls. Settings are stored locally.",
      date:"2026-08-16",
      pinned:true,
      isNew:true
    },
    {
      id:"media",
      title: state.language === "zh" ? "媒体中心优化" : "Media Center Improvements",
      content: state.language === "zh"
        ? "音乐、照片和文件中心继续保持本地运行，不需要上传到服务器。"
        : "Music, Photos and Files remain local-first and do not require server uploads.",
      date:"2026-08-15",
      pinned:false,
      isNew:false
    },
    {
      id:"security",
      title: state.language === "zh" ? "系统安全提示" : "System Security Notice",
      content: state.language === "zh"
        ? "锁屏 PIN 仅用于前端锁屏保护。不要把它当作真正的账户密码或服务器级安全措施。"
        : "The lock PIN only protects the front-end lock screen. Do not treat it as an account password or server-grade security.",
      date:"2026-08-15",
      pinned:false,
      isNew:false
    }
  ];

}

function isAnnouncementRead(id){
  return Array.isArray(state.announcementRead) && state.announcementRead.includes(id);
}

function markAnnouncementRead(id){

  if(!Array.isArray(state.announcementRead))
    state.announcementRead = [];

  if(!state.announcementRead.includes(id))
    state.announcementRead.push(id);

  saveState();
  updateAnnouncementBar();
  renderAnnouncements();

}

function markAllAnnouncementsRead(){

  state.announcementRead =
    getAnnouncements().map(item => item.id);

  saveState();
  updateAnnouncementBar();
  renderAnnouncements();
  toast(t("announcementRead"));

}

function updateAnnouncementBar(){

  const bar = $("announcementBarText");
  if(!bar)
    return;

  const list = getAnnouncements();
  const unread = list.filter(item => !isAnnouncementRead(item.id));
  const current = unread[0] || list[0];

  bar.textContent = current ? current.title : t("noAnnouncements");

}

function renderAnnouncements(){

  const box = $("announcementList");
  if(!box)
    return;

  const list = getAnnouncements();

  if(!list.length){
    box.innerHTML = `<div class="section"><div class="muted">${t("noAnnouncements")}</div></div>`;
    return;
  }

  box.innerHTML = "";

  list.forEach(item => {

    const unread = !isAnnouncementRead(item.id);
    const card = document.createElement("div");
    card.className = "announcementCard" + (unread ? " unread" : "");

    const top = document.createElement("div");
    top.className = "announcementTop";

    const title = document.createElement("div");
    title.className = "announcementTitle";
    title.textContent = item.title;

    top.appendChild(title);

    if(item.pinned){
      const badge = document.createElement("span");
      badge.className = "announcementBadge";
      badge.textContent = "📌 " + t("announcementPinned");
      top.appendChild(badge);
    }

    if(item.isNew && unread){
      const badge = document.createElement("span");
      badge.className = "announcementBadge";
      badge.textContent = t("announcementNew");
      top.appendChild(badge);
    }

    const content = document.createElement("div");
    content.className = "announcementContent";
    content.textContent = item.content;

    const date = document.createElement("div");
    date.className = "announcementDate";
    date.textContent = item.date + " · " + (unread ? t("announcementUnread") : t("announcementRead"));

    card.appendChild(top);
    card.appendChild(content);
    card.appendChild(date);

    if(unread){
      const actions = document.createElement("div");
      actions.className = "announcementActions";

      const readBtn = document.createElement("button");
      readBtn.className = "btn";
      readBtn.textContent = t("markRead");
      readBtn.addEventListener("click", () => markAnnouncementRead(item.id));

      actions.appendChild(readBtn);
      card.appendChild(actions);
    }

    box.appendChild(card);

  });

}

function noticeHTML(){

  return `
    <div class="modalHead">
      <h2>📢 ${t("announcementCenter")}</h2>
      <button class="close" data-close>×</button>
    </div>

    <div class="modalBody">

      <div class="section">
        <div class="sectionTitle">${t("announcementLatest")}</div>
        <div class="muted">ZEN OS V19</div>
      </div>

      <div id="announcementList"></div>

      <button
        class="btn primary"
        style="width:100%;margin-top:4px"
        id="markAllAnnouncementsRead">
        ✓ ${t("markAllRead")}
      </button>

      <button
        class="btn"
        style="width:100%;margin-top:10px"
        data-close>
        ${t("complete")}
      </button>

    </div>
  `;

}


/* =========================================================
   SETTINGS
========================================================= */

function profileHTML(){
  const avatar = state.profileAvatar
    ? `<img src="${escapeHtml(state.profileAvatar)}" alt="Avatar">`
    : `<span>${escapeHtml((state.profileNickname || "十").slice(0,1))}</span>`;
  return `
    <div class="modalHead">
      <h2>👤 ${t("profileCenter")}</h2>
      <button class="close" data-close>×</button>
    </div>
    <div class="modalBody">
      <div class="section" style="text-align:center">
        <div id="profileAvatarPreview" style="width:92px;height:92px;border-radius:28px;margin:0 auto 14px;display:flex;align-items:center;justify-content:center;overflow:hidden;background:linear-gradient(135deg,#6757ff,#8b7cff);color:#fff;font-size:36px;font-weight:800;box-shadow:0 12px 30px rgba(0,0,0,.22)">${avatar}</div>
        <input id="profileAvatarInput" type="file" accept="image/*" hidden>
        <div class="row" style="justify-content:center">
          <button class="btn" id="chooseProfileAvatar">🖼️ ${t("chooseAvatar")}</button>
          <button class="btn danger" id="resetProfileAvatar">${t("resetAvatar")}</button>
        </div>
      </div>
      <div class="section">
        <div class="sectionTitle">${t("nickname")}</div>
        <input class="input" id="profileNicknameInput" maxlength="40" value="${escapeHtml(state.profileNickname)}" placeholder="${t("nickname")}" autocomplete="nickname">
      </div>
      <div class="section">
        <div class="sectionTitle">${t("signature")}</div>
        <textarea class="input" id="profileSignatureInput" maxlength="120" rows="3" style="resize:vertical" placeholder="${t("signature")}">${escapeHtml(state.profileSignature)}</textarea>
      </div>
      <div class="section">
        <div class="sectionTitle">${t("profileStatus")}</div>
        <select class="input" id="profileStatusSelect">
          <option value="online" ${state.profileStatus === "online" ? "selected" : ""}>🟢 ${t("statusOnline")}</option>
          <option value="busy" ${state.profileStatus === "busy" ? "selected" : ""}>🔴 ${t("statusBusy")}</option>
          <option value="away" ${state.profileStatus === "away" ? "selected" : ""}>🟡 ${t("statusAway")}</option>
          <option value="offline" ${state.profileStatus === "offline" ? "selected" : ""}>⚪ ${t("statusOffline")}</option>
        </select>
      </div>
      <div class="muted" style="margin-bottom:14px">${t("localProfileNote")}</div>
      <button class="btn primary" id="saveProfile" style="width:100%">${t("saveProfile")}</button>
    </div>`;
}

function updateProfilePreview(){
  const box = $("profileAvatarPreview");
  if(!box) return;
  const name = $("profileNicknameInput")?.value.trim() || state.profileNickname || "十";
  box.innerHTML = state.profileAvatar
    ? `<img src="${escapeHtml(state.profileAvatar)}" alt="Avatar" style="width:100%;height:100%;object-fit:cover">`
    : `<span>${escapeHtml(name.slice(0,1))}</span>`;
}

function updateQuickProfile(){
  const box = $("profileQuickAvatar");
  if(!box) return;
  if(state.profileAvatar){
    box.innerHTML = `<img src="${escapeHtml(state.profileAvatar)}" alt="Avatar" style="width:100%;height:100%;object-fit:cover;border-radius:inherit">`;
  }else{
    box.textContent = (state.profileNickname || "十").slice(0,1);
  }
}

function settingsHTML(){

  return `
    <div class="modalHead">

      <h2>⚙️ ${t("settings")}</h2>

      <button class="close" data-close>×</button>

    </div>

    <div class="modalBody">

      <div class="section">

        <div class="sectionTitle">
          🎨 ${t("theme")}
        </div>

        <select id="themeSelect">

          <option
            value="dark"
            ${state.theme==="dark"?"selected":""}>
            ${t("dark")}
          </option>

          <option
            value="light"
            ${state.theme==="light"?"selected":""}>
            ${t("light")}
          </option>

          <option
            value="auto"
            ${state.theme==="auto"?"selected":""}>
            ${t("auto")}
          </option>

        </select>

      </div>


      <div class="section">

        <div class="sectionTitle">
          🌐 ${t("language")}
        </div>

        <select id="languageSelect">

          <option
            value="zh"
            ${state.language==="zh"?"selected":""}>
            中文
          </option>

          <option
            value="en"
            ${state.language==="en"?"selected":""}>
            English
          </option>

        </select>

      </div>


      <div class="section">

        <div class="sectionTitle">
          ✨ ${t("float")}
        </div>

        <div class="muted">
          ${escapeHtml(state.floatText)}
        </div>

        <button
          class="btn"
          style="width:100%;margin-top:10px"
          id="openFloat">
          ✨ ${t("float")}
        </button>

      </div>


      <div class="section">

        <div class="sectionTitle">
          ⚡ ${t("performance")}
        </div>

        <button
          class="toggle ${state.performance?"on":""}"
          id="performanceToggle">

          <i></i>

        </button>

        <div class="muted">
          ${
            state.performance
              ? t("enabled")
              : t("disabled")
          }
        </div>

      </div>


      <div class="section">

        <div class="sectionTitle">
          🔒 ${t("pin")}
        </div>

        <input
          id="newPin"
          class="input"
          maxlength="4"
          inputmode="numeric"
          placeholder="4 digit PIN">

        <div class="row" style="margin-top:10px">

          <button
            class="btn primary"
            id="savePin">
            ${t("save")}
          </button>

          <button
            class="btn danger"
            id="removePin">
            ${t("clear")}
          </button>

        </div>

      </div>


      <div class="section">

        <div class="sectionTitle">
          🧹 ${t("system")}
        </div>

        <button
          class="btn danger"
          style="width:100%"
          id="resetSystem">
          ${t("reset")}
        </button>

      </div>


      <button
        class="btn"
        style="width:100%"
        data-close>
        ${t("complete")}
      </button>

    </div>
  `;

}


/* =========================================================
   SERVER API UI
========================================================= */

function serverApiHTML(){
  return `
    <div class="modalHead">
      <h2>🛰️ ${t("serverApi")}</h2>
      <button class="close" data-close>×</button>
    </div>
    <div class="modalBody">
      <div class="section">
        <div class="sectionTitle">${t("serverApiUrl")}</div>
        <input id="serverApiUrl" class="input" value="${escapeHtml(state.serverApiUrl)}" placeholder="/api 或 https://example.com/api">
        <div class="muted" style="margin-top:8px">GET /health · GET /announcements?lang=zh</div>
      </div>
      <div class="section">
        <div class="row" style="align-items:center">
          <div style="flex:1"><b>${t("serverApiEnabled")}</b></div>
          <button class="toggle ${state.serverApiEnabled?"on":""}" id="serverApiEnabled"><i></i></button>
        </div>
        <div class="row" style="align-items:center;margin-top:14px">
          <div style="flex:1"><b>${t("serverApiAnnouncements")}</b></div>
          <button class="toggle ${state.serverApiAnnouncements?"on":""}" id="serverApiAnnouncements"><i></i></button>
        </div>
      </div>
      <div class="row">
        <button class="btn primary" id="saveServerApi">${t("apiSave")}</button>
        <button class="btn" id="testServerApi">${t("apiTest")}</button>
      </div>
      <div class="muted" style="margin-top:12px">同源部署推荐使用 /api；跨域部署需要服务器允许 CORS。服务器不可用时，ZEN OS 会继续使用内置公告。</div>
    </div>
  `;
}

/* =========================================================
   SEARCH
========================================================= */

const APPS = [

  ["🎵","音乐","music"],
  ["🎮","游戏","game"],
  ["🧮","工具箱","tools"],
  ["🧾","计算器","calculator"],
  ["📁","文件","files"],
  ["🖼️","照片","photos"],
  ["✨","浮字引擎","float"],
  ["🌐","翻译器","translator"],
  ["🔔","通知","notice"],
  ["👤","个人中心","profile"],
  ["⚙️","设置","settings"],
  ["⚡","系统状态","system"],
  ["🕐","时间中心","calendar"],
  ["✈️","Telegram 社群","telegram"],
  ["ℹ️","关于","about"],
  ["🎛️","控制中心","control"],
  ["⏱️","秒表","stopwatch"],
  ["🔢","2048","game2048"]

];


function searchHTML(){

  return `
    <div class="modalHead">

      <h2>🔍 ${t("search")}</h2>

      <button class="close" data-close>×</button>

    </div>

    <div class="modalBody">

      <input
        class="input"
        id="searchInput"
        placeholder="${t("searchApp")}"
        autocomplete="off">

      <div
        id="searchResults"
        style="margin-top:10px">
      </div>

    </div>
  `;

}


function searchApps(value){

  const result =
    $("searchResults");

  if(!result)
    return;

  result.innerHTML = "";

  const q =
    String(value || "")
      .trim()
      .toLowerCase();

  if(!q)
    return;

  const matches =
    APPS.filter(app => {

      const name =
        app[1].toLowerCase();

      const key =
        app[2].toLowerCase();

      const translated =
        t(app[2]).toLowerCase();

      return (
        name.includes(q) ||
        key.includes(q) ||
        translated.includes(q)
      );

    });

  if(!matches.length){

    result.innerHTML =
      `<div class="muted">
        ${t("noResult")}
      </div>`;

    return;

  }

  matches.forEach(app => {

    const div =
      document.createElement("div");

    div.className =
      "searchResult";

    div.textContent =
      app[0] + "  " + t(app[2]);

    div.addEventListener(
      "click",
      () => {

        closeModal();

        setTimeout(
          () => openModal(app[2]),
          50
        );

      }
    );

    result.appendChild(div);

  });

}


/* =========================================================
   CONTROL CENTER / EXTRA APPS V19
========================================================= */

function controlHTML(){
  return `
    <div class="modalHead">
      <h2>🎛️ ${t("controlCenterTitle")}</h2>
      <button class="close" data-close>×</button>
    </div>
    <div class="modalBody">
      <div class="controlGrid">
        <div class="controlItem">
          <b>🖥️ ${t("fullscreen")}</b>
          <div class="muted">Browser fullscreen mode</div>
          <button class="btn primary" style="width:100%;margin-top:10px" id="fullscreenBtn">${t("fullscreen")}</button>
        </div>
        <div class="controlItem">
          <b>🌌 ${t("wallpaper")}</b>
          <div class="muted" id="wallpaperStatus"></div>
          <button class="btn" style="width:100%;margin-top:10px" id="wallpaperToggle">${t("wallpaper")}</button>
        </div>
        <div class="controlItem">
          <b>⚡ ${t("performance")}</b>
          <div class="muted">${state.performance ? t("enabled") : t("disabled")}</div>
          <button class="btn" style="width:100%;margin-top:10px" id="controlPerformance">${t("performance")}</button>
        </div>
        <div class="controlItem">
          <b>🔋 ${t("systemBattery")}</b>
          <div class="muted" id="controlBattery">${$("systemBattery")?.textContent || "—"}</div>
        </div>
      </div>
      <button class="btn" style="width:100%;margin-top:14px" data-close>${t("complete")}</button>
    </div>`;
}

function syncControlUI(){
  const s=$("wallpaperStatus");
  if(s) s.textContent=state.dynamicWallpaper ? t("wallpaperOn") : t("wallpaperOff");
  const b=$("controlBattery");
  if(b) b.textContent=$("systemBattery")?.textContent || "—";
}

function toggleDynamicWallpaper(){
  state.dynamicWallpaper=!state.dynamicWallpaper;
  saveState();
  document.body.classList.toggle("dynamicWallpaper", state.dynamicWallpaper && !state.performance);
  toast(state.dynamicWallpaper ? t("wallpaperOn") : t("wallpaperOff"));
  syncControlUI();
}

async function toggleFullscreen(){
  try{
    if(document.fullscreenElement){
      await document.exitFullscreen();
    }else if(document.documentElement.requestFullscreen){
      await document.documentElement.requestFullscreen();
    }else{
      toast(state.language === "zh" ? "浏览器不支持全屏" : "Fullscreen unavailable");
    }
  }catch(e){
    toast(state.language === "zh" ? "全屏请求被阻止" : "Fullscreen request blocked");
  }
}

let stopwatchTimer=null;
let stopwatchStarted=0;
let stopwatchElapsed=0;

function stopwatchHTML(){
  return `
    <div class="modalHead"><h2>⏱️ ${t("stopwatch")}</h2><button class="close" data-close>×</button></div>
    <div class="modalBody">
      <div class="section">
        <div id="stopwatchTime" class="stopwatchTime">00:00.00</div>
        <div class="stopwatchButtons">
          <button class="btn primary" id="stopwatchStart">${t("start")}</button>
          <button class="btn" id="stopwatchReset">${t("resetTimer")}</button>
        </div>
      </div>
      <button class="btn" style="width:100%" data-close>${t("complete")}</button>
    </div>`;
}

function stopwatchValue(){
  return stopwatchElapsed + (stopwatchTimer ? performance.now()-stopwatchStarted : 0);
}
function formatStopwatch(ms){
  const cs=Math.floor(ms/10)%100;
  const sec=Math.floor(ms/1000)%60;
  const min=Math.floor(ms/60000);
  return String(min).padStart(2,"0")+":"+String(sec).padStart(2,"0")+"."+String(cs).padStart(2,"0");
}
function renderStopwatch(){
  const el=$("stopwatchTime");
  if(el) el.textContent=formatStopwatch(stopwatchValue());
}
function toggleStopwatch(){
  if(stopwatchTimer){
    stopwatchElapsed=stopwatchValue();
    clearInterval(stopwatchTimer); stopwatchTimer=null;
  }else{
    stopwatchStarted=performance.now();
    stopwatchTimer=setInterval(renderStopwatch,40);
  }
  renderStopwatch();
  const btn=$("stopwatchStart");
  if(btn) btn.textContent=stopwatchTimer ? t("pause") : t("start");
}
function resetStopwatch(){
  if(stopwatchTimer){clearInterval(stopwatchTimer);stopwatchTimer=null;}
  stopwatchElapsed=0; stopwatchStarted=0; renderStopwatch();
  const btn=$("stopwatchStart"); if(btn) btn.textContent=t("start");
}

let board2048=[];
function new2048(){
  board2048=Array(16).fill(0);
  add2048Tile(); add2048Tile(); render2048();
}
function add2048Tile(){
  const empty=[]; board2048.forEach((v,i)=>{if(!v) empty.push(i);});
  if(!empty.length) return;
  const i=empty[Math.floor(Math.random()*empty.length)];
  board2048[i]=Math.random()<.9?2:4;
}
function slide2048(row){
  const a=row.filter(Boolean);
  for(let i=0;i<a.length-1;i++){
    if(a[i]===a[i+1]){a[i]*=2;a.splice(i+1,1);}
  }
  while(a.length<4)a.push(0);
  return a;
}
function move2048(dir){
  const old=board2048.slice();
  if(dir==="left"||dir==="right"){
    for(let r=0;r<4;r++){
      let row=board2048.slice(r*4,r*4+4);
      if(dir==="right")row.reverse();
      row=slide2048(row);
      if(dir==="right")row.reverse();
      board2048.splice(r*4,4,...row);
    }
  }else{
    for(let c=0;c<4;c++){
      let col=[0,1,2,3].map(r=>board2048[r*4+c]);
      if(dir==="down")col.reverse();
      col=slide2048(col);
      if(dir==="down")col.reverse();
      for(let r=0;r<4;r++)board2048[r*4+c]=col[r];
    }
  }
  if(board2048.some((v,i)=>v!==old[i])) add2048Tile();
  render2048();
}
function render2048(){
  const box=$("game2048Board"); if(!box)return;
  box.innerHTML="";
  board2048.forEach(v=>{const d=document.createElement("div");d.className="tile2048";d.textContent=v||"";box.appendChild(d);});
}
function game2048HTML(){
  if(!board2048.length)new2048();
  return `
    <div class="modalHead"><h2>🔢 ${t("game2048")}</h2><button class="close" data-close>×</button></div>
    <div class="modalBody">
      <div class="game2048Hint">Swipe / Arrow keys · ${t("newGame")}</div>
      <div id="game2048Board" class="game2048" tabindex="0"></div>
      <button class="btn primary" style="width:100%;margin-top:12px" id="new2048">${t("newGame")}</button>
      <button class="btn" style="width:100%;margin-top:10px" data-close>${t("complete")}</button>
    </div>`;
}

/* =========================================================
   ABOUT
========================================================= */

function openTelegramCommunity(){

  const url = TELEGRAM_COMMUNITY_URL;
  if(!url) return;

  try{
    const opened = window.open(url, "_blank", "noopener,noreferrer");
    if(!opened){
      window.location.href = url;
    }
  }catch(err){
    window.location.href = url;
  }

}


function aboutHTML(){

  return `
    <div class="modalHead">

      <h2>ZEN OS</h2>

      <button class="close" data-close>×</button>

    </div>

    <div class="modalBody">

      <div style="text-align:center;padding:25px 0">

        <div class="lockLogo">
          Z
        </div>

        <h2>
          ZEN OS V19
        </h2>

        <div class="muted">
          Web Desktop Edition
        </div>

      </div>

      <div class="section">

        <b>Core Runtime</b>

        <div class="muted" style="margin-top:8px">
          UI Engine · Stable
        </div>

        <div class="muted">
          Local Storage · Protected
        </div>

        <div class="muted">
          Theme Engine · Stable
        </div>

        <div class="muted">
          Language Engine · Stable
        </div>

        <div class="muted">
          Battery API · Compatible
        </div>

        <div class="muted">
          Local Media Engine · Stable
        </div>

      </div>

      <button
        class="btn primary"
        style="width:100%;margin-bottom:10px"
        id="aboutTelegram">
        ✈️ ${t("telegram")}
      </button>

      <button
        class="btn"
        style="width:100%"
        data-close>
        ${t("complete")}
      </button>

    </div>
  `;

}


/* =========================================================
   EVENT DELEGATION
========================================================= */

document.addEventListener(
  "click",
  event => {

    const card =
      event.target.closest("[data-action]");

    if(card){

      openModal(
        card.dataset.action
      );

      return;

    }

    const dock =
      event.target.closest("[data-dock]");

    if(dock){

      openModal(
        dock.dataset.dock
      );

      return;

    }

    if(
      event.target.closest("[data-close]")
    ){

      closeModal();
      return;

    }

    const music =
      event.target.closest("[data-music]");

    if(music){

      const action =
        music.dataset.music;

      if(action === "play")
        playPause();

      if(action === "next")
        nextTrack();

      if(action === "prev")
        previousTrack();

      return;

    }

    const track =
      event.target.closest("[data-track]");

    if(track){

      loadTrack(
        Number(track.dataset.track)
      );

      return;

    }

  }
);


/* =========================================================
   INPUT
========================================================= */

document.addEventListener(
  "input",
  event => {

    if(
      event.target.id === "searchInput"
    ){

      searchApps(
        event.target.value
      );

    }

    if(
      event.target.id === "fileSearch"
    ){

      renderFiles(
        event.target.value
      );

    }

    if(["floatSpeed","floatDensity","floatOpacity","floatSize","floatMax"].includes(event.target.id)){
      const key=event.target.id;
      state[key]=Number(event.target.value);
      normalizeFloatSettings();
      updateFloatControlLabels();
      saveState();
      scheduleFloatEngine();
    }

    if(
      event.target.id === "translateInput"
    ){
      if($("translateResult"))
        $("translateResult").textContent = "";
    }

    if(
      event.target.id === "musicSeek"
    ){

      const audio =
        $("audioPlayer");

      if(
        audio &&
        Number.isFinite(audio.duration) &&
        audio.duration > 0
      ){

        audio.currentTime =
          Number(event.target.value) /
          100 *
          audio.duration;

      }

    }

  }
);


/* =========================================================
   CHANGE
========================================================= */

document.addEventListener(
  "keydown",
  event => {
    if(event.target?.id === "translateInput" && event.key === "Enter" && !event.shiftKey){
      event.preventDefault();
      doTranslate();
    }
  }
);


document.addEventListener(
  "change",
  event => {

    if(event.target.id === "floatModeSelect"){
      state.floatMode = event.target.value;
      saveFloatSettingsFromUI();
    }

    if(["floatSpeed","floatDensity","floatOpacity","floatSize","floatMax"].includes(event.target.id)){
      saveFloatSettingsFromUI();
      updateFloatControlLabels();
    }

    if(
      event.target.id === "themeSelect"
    ){

      state.theme =
        event.target.value;

      saveState();
      applyTheme();

      toast(themeName());

    }


    if(
      event.target.id === "languageSelect"
    ){

      state.language =
        event.target.value;

      saveState();
      applyLanguage();

      if(currentModal){

        const old =
          currentModal;

        openModal(old);

      }

    }


    if(
      event.target.id === "musicInput"
    ){

      loadMusicFiles(
        event.target.files
      );

    }


    if(
      event.target.id === "fileInput"
    ){

      loadFiles(
        event.target.files
      );

    }


    if(
      event.target.id === "photoInput"
    ){

      loadPhotos(
        event.target.files
      );

    }

    if(event.target.id === "profileAvatarInput"){
      const file = event.target.files?.[0];
      if(file && file.type.startsWith("image/")){
        const reader = new FileReader();
        reader.onload = () => {
          state.profileAvatar = String(reader.result || "");
          updateProfilePreview();
        };
        reader.readAsDataURL(file);
      }
    }

  }
);


/* =========================================================
   SPECIAL ACTIONS
========================================================= */

document.addEventListener(
  "click",
  event => {

    const id =
      event.target.id;

    if(id === "saveServerApi"){
      const input = $("serverApiUrl");
      if(input) state.serverApiUrl = input.value.trim() || "https://zenos-91.onrender.com/api";
      saveState();
      serverAnnouncements = null;
      toast(t("apiSaved"));
      testServerApi().then(ok => { if(ok) syncServerAnnouncements(); });
      return;
    }

    if(id === "testServerApi"){
      testServerApi().then(ok => { if(ok) syncServerAnnouncements(); });
      return;
    }

    if(id === "serverApiEnabled"){
      state.serverApiEnabled = !state.serverApiEnabled;
      saveState();
      if(state.serverApiEnabled) syncServerAnnouncements();
      return;
    }

    if(id === "serverApiAnnouncements"){
      state.serverApiAnnouncements = !state.serverApiAnnouncements;
      saveState();
      if(state.serverApiAnnouncements) syncServerAnnouncements();
      return;
    }

    if(id === "aboutTelegram")
      openTelegramCommunity();

    if(id === "profileQuick")
      openModal("profile");

    if(id === "chooseProfileAvatar"){
      const input = $("profileAvatarInput");
      if(input) input.click();
    }

    if(id === "resetProfileAvatar"){
      state.profileAvatar = "";
      updateProfilePreview();
    }

    if(id === "saveProfile"){
      state.profileNickname = ($("profileNicknameInput")?.value.trim() || "十壹").slice(0,40);
      state.profileSignature = ($("profileSignatureInput")?.value.trim() || "ZEN OS 用户").slice(0,120);
      const status = $("profileStatusSelect")?.value || "online";
      state.profileStatus = ["online","busy","away","offline"].includes(status) ? status : "online";
      saveState();
      updateQuickProfile();
      toast(t("profileSaved"));
      return;
    }

    if(id === "randomBtn")
      generateRandom();


    if(id === "guessBtn")
      makeGuess();


    if(id === "newGameBtn")
      newGame();


    if(id === "translateBtn")
      doTranslate();


    if(id === "translateClear"){

      if($("translateInput"))
        $("translateInput").value = "";

      if($("translateResult"))
        $("translateResult").textContent = "";

    }


    if(id === "saveFloat")
      saveFloat();

    if(id === "floatPreview")
      createFloatText();

    if(id === "floatReset")
      resetFloatSettings();


    if(id === "floatToggle"){

      state.floatEnabled =
        !state.floatEnabled;

      saveState();

      toast(
        state.floatEnabled
          ? t("floatOn")
          : t("floatOff")
      );

      openModal("float");

    }


    if(id === "photoClear"){

      state.photos.forEach(
        photo => {

          try{
            URL.revokeObjectURL(photo.url);
          }catch(e){}

        }
      );

      state.photos = [];

      renderPhotos();

    }


    if(id === "savePin"){

      const input =
        $("newPin");

      const pin =
        input
          ? input.value.trim()
          : "";

      if(!/^\d{4}$/.test(pin)){

        toast(
          state.language === "zh"
            ? "请输入4位数字"
            : "Enter 4 digits"
        );

        return;

      }

      state.pin = pin;

      saveState();

      toast(t("saved"));

      if(input)
        input.value = "";

    }


    if(id === "removePin"){

      state.pin = "";

      saveState();

      toast(
        state.language === "zh"
          ? "PIN 已删除"
          : "PIN removed"
      );

    }


    if(id === "openFloat")
      openModal("float");


    if(id === "resetSystem")
      resetSystem();


    if(id === "performanceToggle"){

      state.performance =
        !state.performance;

      document.body.classList.toggle(
        "performance",
        state.performance
      );
      applyTheme();
      scheduleFloatEngine();

      saveState();

      /* 统一由 scheduleFloatEngine 管理浮字定时器，避免重复创建。 */
      scheduleFloatEngine();

      toast(
        state.performance
          ? t("enabled")
          : t("disabled")
      );

      openModal("settings");

    }


    if(id === "markAllAnnouncementsRead")
      markAllAnnouncementsRead();

    if(id === "fullscreenBtn")
      toggleFullscreen();

    if(id === "wallpaperToggle")
      toggleDynamicWallpaper();

    if(id === "controlPerformance"){
      state.performance=!state.performance;
      document.body.classList.toggle("performance",state.performance);
      document.body.classList.toggle("dynamicWallpaper",state.dynamicWallpaper && !state.performance);
      scheduleFloatEngine();
      saveState();
      syncControlUI();
      toast(state.performance ? t("enabled") : t("disabled"));
    }

    if(id === "stopwatchStart")
      toggleStopwatch();

    if(id === "stopwatchReset")
      resetStopwatch();

    if(id === "new2048")
      new2048();

    if(id === "copyTimestamp"){

      const timestamp =
        $("timestamp");

      if(timestamp)
        copyText(timestamp.textContent);

    }

    if(event.target.closest("[data-calc]")){
      calculatorInput(event.target.closest("[data-calc]").dataset.calc);
    }

  }
);


/* =========================================================
   TRANSLATOR
========================================================= */

function resetFloatSettings(){
  state.floatMode="rise";
  state.floatSpeed=1;
  state.floatDensity=1;
  state.floatOpacity=.55;
  state.floatSize=16;
  state.floatMax=18;
  saveState();
  scheduleFloatEngine();
  openModal("float");
  toast(t("floatReset"));
}

function doTranslate(){

  const input = $("translateInput");
  const result = $("translateResult");
  const source = $("sourceLanguage");
  const target = $("targetLanguage");

  if(!input || !result || !source || !target)
    return;

  const text = input.value.trim();

  if(!text){
    result.textContent = "";
    return;
  }

  result.textContent = localTranslate(
    text,
    source.value || "zh",
    target.value || "en"
  );

}

function swapLanguages(){

  const source = $("sourceLanguage");
  const target = $("targetLanguage");
  const input = $("translateInput");
  const result = $("translateResult");

  if(!source || !target)
    return;

  const oldSource = source.value;
  source.value = target.value;
  target.value = oldSource;

  if(input && input.value.trim()){
    if(result)
      result.textContent = "";
    doTranslate();
  }

}


document.addEventListener("click", event => {

  if(event.target.closest("#swapLanguages"))
    swapLanguages();

});


/* =========================================================
   QUICK THEME
========================================================= */

if($("themeQuick")){

  $("themeQuick").addEventListener(
    "click",
    cycleTheme
  );

}


/* =========================================================
   LOCK EVENTS
========================================================= */

if($("unlockBtn")){

  $("unlockBtn").addEventListener(
    "click",
    unlock
  );

}


if($("directBtn")){

  $("directBtn").addEventListener(
    "click",
    enterSystem
  );

}


if($("pinInput")){

  $("pinInput").addEventListener(
    "keydown",
    event => {

      if(event.key === "Enter")
        unlock();

    }
  );

}


/* =========================================================
   MODAL OUTSIDE
========================================================= */

if($("modal")){

  $("modal").addEventListener(
    "click",
    event => {

      if(
        event.target === $("modal")
      ){

        closeModal();

      }

    }
  );

}


/* =========================================================
   VIEWER
========================================================= */

if($("viewer")){

  $("viewer").addEventListener(
    "click",
    event => {

      if(
        event.target === $("viewer") ||
        event.target === $("viewerClose")
      ){

        closeViewer();

      }

    }
  );

}


/* =========================================================
   KEYBOARD
========================================================= */

document.addEventListener(
  "keydown",
  event => {

    if(currentModal === "game2048" && ["ArrowLeft","ArrowRight","ArrowUp","ArrowDown"].includes(event.key)){
      event.preventDefault();
      move2048(event.key === "ArrowLeft" ? "left" : event.key === "ArrowRight" ? "right" : event.key === "ArrowUp" ? "up" : "down");
      return;
    }

    if(event.key === "Escape"){
      closeModal();
      closeViewer();
    }

  }
);


let gameTouchStart=null;
document.addEventListener("touchstart",e=>{ if(currentModal==="game2048" && e.touches[0]) gameTouchStart={x:e.touches[0].clientX,y:e.touches[0].clientY}; },{passive:true});
document.addEventListener("touchend",e=>{
  if(currentModal!=="game2048" || !gameTouchStart || !e.changedTouches[0]) return;
  const t0=e.changedTouches[0], dx=t0.clientX-gameTouchStart.x, dy=t0.clientY-gameTouchStart.y;
  gameTouchStart=null;
  if(Math.max(Math.abs(dx),Math.abs(dy))<28) return;
  move2048(Math.abs(dx)>Math.abs(dy)?(dx>0?"right":"left"):(dy>0?"down":"up"));
},{passive:true});

/* =========================================================
   RESET
========================================================= */

function clearMediaResources(){

  state.musicTracks.forEach(track => {
    try{
      if(track && typeof track.url === "string" && track.url.startsWith("blob:"))
        URL.revokeObjectURL(track.url);
    }catch(e){}
  });

  state.photos.forEach(photo => {
    try{
      if(photo && typeof photo.url === "string" && photo.url.startsWith("blob:"))
        URL.revokeObjectURL(photo.url);
    }catch(e){}
  });

  state.musicTracks = [];
  state.photos = [];
  state.currentTrack = -1;
}

function resetSystem(){

  let ok = false;

  try{

    ok =
      confirm(
        state.language === "zh"
          ? "确定要重置 ZEN OS 设置吗？"
          : "Reset ZEN OS settings?"
      );

  }catch(e){

    ok = false;

  }

  if(!ok)
    return;

  try{

    localStorage.removeItem(
      STORE_KEY
    );

  }catch(e){}

  state.theme = "dark";
  state.language = "zh";
  state.floatEnabled = true;
  state.floatText = "ZEN OS";
  state.floatMode = "rise";
  state.floatSpeed = 1;
  state.floatDensity = 1;
  state.floatOpacity = .55;
  state.floatSize = 16;
  state.floatMax = 18;
  state.performance = false;
  state.pin = "";
  state.profileNickname = "十壹";
  state.profileSignature = "ZEN OS 用户";
  state.profileStatus = "online";
  state.profileAvatar = "";
  state.announcementRead = [];

  applyTheme();
  applyLanguage();

  document.body.classList.remove(
    "performance"
  );

  toast(t("resetDone"));

  setTimeout(
    () => {

      try{
        location.reload();
      }catch(e){}

    },
    700
  );

}


/* =========================================================
   COPY
========================================================= */

async function copyText(text){

  const value =
    String(text ?? "");

  try{

    if(
      navigator.clipboard &&
      window.isSecureContext
    ){

      await navigator.clipboard.writeText(
        value
      );

      toast(t("copied"));

      return;

    }

  }catch(e){}

  try{

    const textarea =
      document.createElement("textarea");

    textarea.value = value;

    textarea.style.position = "fixed";
    textarea.style.left = "-9999px";
    textarea.style.opacity = "0";

    document.body.appendChild(
      textarea
    );

    textarea.focus();
    textarea.select();

    const ok =
      document.execCommand("copy");

    textarea.remove();

    toast(
      ok
        ? t("copied")
        : "Copy unavailable"
    );

  }catch(err){

    toast("Copy unavailable");

  }

}


/* =========================================================
   UTILS
========================================================= */

function formatSize(bytes){

  const n =
    Number(bytes);

  if(!Number.isFinite(n))
    return "0 B";

  if(n < 1024)
    return n + " B";

  if(n < 1024*1024)
    return (
      n/1024
    ).toFixed(1) + " KB";

  if(n < 1024*1024*1024)
    return (
      n/1024/1024
    ).toFixed(1) + " MB";

  return (
    n/1024/1024/1024
  ).toFixed(1) + " GB";

}


function escapeHtml(str){

  return String(str ?? "")
    .replace(/&/g,"&amp;")
    .replace(/</g,"&lt;")
    .replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;")
    .replace(/'/g,"&#039;");

}


function escapeRegExp(str){

  return String(str ?? "")
    .replace(
      /[.*+?^${}()|[\]\\]/g,
      "\\$&"
    );

}


/* =========================================================
   VISIBILITY
========================================================= */

document.addEventListener(
  "visibilitychange",
  () => {

    if(document.hidden)
      clearFloatLayer();

  }
);


window.addEventListener("resize",()=>{
  if(currentModal==="music" && audioAnalyser) drawSpectrum();
});

/* =========================================================
   SYSTEM PREFERENCE
========================================================= */

if(window.matchMedia){

  try{

    const media =
      window.matchMedia(
        "(prefers-color-scheme:light)"
      );

    if(media.addEventListener){

      media.addEventListener(
        "change",
        () => {

          if(state.theme === "auto")
            applyTheme();

        }
      );

    }

  }catch(e){}

}


/* =========================================================
   RESOURCE CLEANUP
========================================================= */

window.addEventListener("beforeunload", () => {

  if(clockTimer)
    clearInterval(clockTimer);

  if(floatTimer)
    clearInterval(floatTimer);

  state.musicTracks.forEach(track => {
    try{
      if(track && typeof track.url === "string" && track.url.startsWith("blob:"))
        URL.revokeObjectURL(track.url);
    }catch(e){}
  });

  state.photos.forEach(photo => {
    try{
      if(photo && typeof photo.url === "string" && photo.url.startsWith("blob:"))
        URL.revokeObjectURL(photo.url);
    }catch(e){}
  });

});


/* =========================================================
   ERROR PROTECTION
========================================================= */

/*
  防止某个非关键 JS 错误直接让整个系统停止。
  关键初始化仍然会正常执行。
*/

window.addEventListener(
  "error",
  event => {

    console.error(
      "ZEN OS runtime error:",
      event.error || event.message
    );

  }
);

window.addEventListener(
  "pagehide",
  () => {
    try{ releaseSpectrumNodes(true); }catch(e){}
    try{
      state.musicTracks.forEach(track => {
        if(track && track.url) URL.revokeObjectURL(track.url);
      });
    }catch(e){}
  }
);

window.addEventListener(
  "unhandledrejection",
  event => {

    console.warn(
      "ZEN OS promise error:",
      event.reason
    );

  }
);


/* =========================================================
   INIT
========================================================= */

(function init(){

  try{

    loadState();
    normalizeFloatSettings();

  }catch(err){

    console.error(
      "loadState failed",
      err
    );

  }


  try{

    applyTheme();

  }catch(err){

    console.error(
      "applyTheme failed",
      err
    );

  }


  try{

    applyLanguage();
updateQuickProfile();

  }catch(err){

    console.error(
      "applyLanguage failed",
      err
    );

  }


  document.body.classList.toggle(
    "performance",
    state.performance
  );


  try{

    updateClock();
    updateNetwork();

  }catch(err){

    console.error(
      "basic runtime failed",
      err
    );

  }


  try{

    initBattery();

  }catch(err){

    console.warn(
      "battery init failed",
      err
    );

  }


  /*
    没有 PIN：
    直接进入系统。

    有 PIN：
    保留锁屏。
  */

  if(!state.pin){

    if($("lock"))
      $("lock").style.display = "none";

    if($("app"))
      $("app").style.display = "flex";

    startRuntime();
    syncServerAnnouncements();

  }else{

    if($("lock"))
      $("lock").style.display = "flex";

    if($("app"))
      $("app").style.display = "none";

    updateClock();

  }

})();
